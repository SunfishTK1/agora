#!/usr/bin/env python3
"""
FastAPI Chat Assistant with Azure OpenAI tool-calling and Milvus retrieval.

- Exposes POST /chat to answer questions about UPenn
- The assistant can call a retrieval tool to search Milvus and assemble context
- Context includes page summaries and full text up to a configurable token budget (default 10,000 tokens)
- Designed for a JavaScript frontend to call directly

Run locally:
  uvicorn chat_assistant_api:app --reload --port 8010
"""
from __future__ import annotations

import os
import logging
from typing import List, Optional

from fastapi import FastAPI, HTTPException, Body, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from dotenv import load_dotenv

from rag.chat_engine import ChatAssistant
from conversation_logger import get_conversation_logger

# Logging
logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"), format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("chat_assistant_api")

# Load environment variables from a local .env file if present
load_dotenv()

# Pydantic models
class ChatMessage(BaseModel):
    role: str = Field(..., pattern="^(user|assistant|system)$")
    content: str = Field(..., min_length=1)

class ChatRequest(BaseModel):
    messages: List[ChatMessage]
    top_k: int = Field(20, ge=1, le=50)
    max_doc_tokens: int = Field(10000, ge=1000, le=50000)
    session_id: Optional[str] = Field(None, description="Optional session ID for conversation tracking")

class Citation(BaseModel):
    rank: int
    title: Optional[str] = None
    url: Optional[str] = None
    path: Optional[str] = None

class ChatResponse(BaseModel):
    answer: str
    citations: List[Citation] = []
    session_id: Optional[str] = Field(None, description="Session ID for conversation tracking")

# FastAPI app
app = FastAPI(
    title="UPenn Chat Assistant API",
    description="Chat assistant with Azure OpenAI tool-calling and Milvus retrieval",
    version="1.0.0",
)

# CORS for JS frontends
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Singleton assistant and conversation logger
assistant: Optional[ChatAssistant] = None
conversation_logger = get_conversation_logger()

@app.on_event("startup")
async def startup_event():
    global assistant
    try:
        assistant = ChatAssistant(
            milvus_db_path=os.getenv("MILVUS_DB_PATH", "./milvus_lite.db"),
            milvus_collection=os.getenv("MILVUS_COLLECTION_NAME", "web_documents"),
        )
        logger.info("ChatAssistant initialized successfully")
    except Exception as e:
        logger.exception("Failed to initialize ChatAssistant")
        raise

@app.get("/health")
async def health():
    return {"status": "ok"}

@app.get("/stats/daily")
async def daily_stats():
    """Get daily conversation statistics."""
    try:
        stats = conversation_logger.get_daily_stats()
        if stats is None:
            return {"message": "Conversation logging not available", "stats": {}}
        return {"stats": stats}
    except Exception as e:
        logger.error(f"Failed to get daily stats: {e}")
        return {"error": "Failed to retrieve statistics", "stats": {}}

@app.get("/stats/session/{session_id}")
async def session_stats(session_id: str):
    """Get statistics for a specific conversation session."""
    try:
        stats = conversation_logger.get_session_stats(session_id)
        if stats is None:
            return {"message": "Session not found or logging not available", "stats": {}}
        return {"session_id": session_id, "stats": stats}
    except Exception as e:
        logger.error(f"Failed to get session stats: {e}")
        return {"error": "Failed to retrieve session statistics", "stats": {}}

@app.get("/stats/quality")
async def response_quality_stats():
    """Get response quality and usefulness statistics."""
    try:
        stats = conversation_logger.get_response_quality_stats()
        if stats is None:
            return {"message": "Quality analysis not available", "stats": {}}
        return {"stats": stats}
    except Exception as e:
        logger.error(f"Failed to get quality stats: {e}")
        return {"error": "Failed to retrieve quality statistics", "stats": {}}

@app.post("/chat", response_model=ChatResponse)
async def chat(request: Request, req: ChatRequest = Body(...)):
    if not assistant:
        raise HTTPException(status_code=503, detail="Assistant not initialized")
    
    try:
        # Get client information for privacy-preserving logging
        client_ip = request.client.host if request.client else "unknown"
        user_agent = request.headers.get("user-agent", "")
        
        # Process chat request
        result = assistant.chat(
            user_messages=[m.model_dump() for m in req.messages],
            top_k=req.top_k,
            max_doc_tokens=req.max_doc_tokens,
        )
        
        # Log conversation to MongoDB with privacy preservation
        session_id = conversation_logger.log_conversation(
            messages=[m.model_dump() for m in req.messages],
            response=result,
            client_ip=client_ip,
            user_agent=user_agent,
            session_id=req.session_id,
            request_params={
                "top_k": req.top_k,
                "max_doc_tokens": req.max_doc_tokens
            }
        )
        
        return ChatResponse(
            answer=result.get("answer", ""), 
            citations=result.get("citations", []),
            session_id=session_id
        )
        
    except Exception as e:
        logger.exception("Chat request failed")
        raise HTTPException(status_code=500, detail=str(e))
