import http from 'http';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = 3000;

console.log("🚀 Enterprise Dashboard Server Starting...");

const server = http.createServer((req, res) => {
  // CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    res.writeHead(200);
    res.end();
    return;
  }

  // Serve the dashboard HTML file
  if (req.url === '/' || req.url === '/dashboard') {
    try {
      const dashboardPath = path.join(__dirname, 'integrated-dashboard.html');
      const dashboardHTML = fs.readFileSync(dashboardPath, 'utf8');
      
      res.setHeader('Content-Type', 'text/html');
      res.writeHead(200);
      res.end(dashboardHTML);
    } catch (error) {
      res.writeHead(500);
      res.end('Error loading dashboard');
    }
    return;
  }

  // Health check
  if (req.url === '/health') {
    res.setHeader('Content-Type', 'application/json');
    res.writeHead(200);
    res.end(JSON.stringify({
      status: 'healthy',
      service: 'Enterprise Dashboard',
      timestamp: new Date().toISOString(),
      features: {
        scraping_management: true,
        vector_integration: true,
        realtime_monitoring: true,
        ai_search: true
      }
    }));
    return;
  }

  // 404 for other routes
  res.writeHead(404);
  res.end('Not Found');
});

server.listen(PORT, () => {
  console.log(`✅ Enterprise Dashboard running on http://localhost:${PORT}`);
  console.log(`📊 Dashboard: http://localhost:${PORT}/dashboard`);
  console.log(`🔗 Health: http://localhost:${PORT}/health`);
  console.log('');
  console.log('🎯 FEATURES AVAILABLE:');
  console.log('   ✅ Domain Management with Duplicate Handling');
  console.log('   ✅ Scraping Job Creation & Monitoring');
  console.log('   ✅ Automatic Vector Embedding Integration');
  console.log('   ✅ Real-time Milvus Database Monitoring');
  console.log('   ✅ AI-Powered Semantic Search');
  console.log('   ✅ Pipeline Health Tracking');
  console.log('');
  console.log('🚀 Ready for Enterprise Operations!');
});

server.on('error', (err) => {
  console.error('❌ Dashboard server error:', err.message);
});
