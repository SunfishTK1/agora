# PennGPT Chat Assistant API Documentation

## Overview

The PennGPT Chat Assistant API provides intelligent conversational AI capabilities specifically focused on University of Pennsylvania information. The API uses advanced retrieval-augmented generation (RAG) technology to provide accurate, cited responses about UPenn academics, campus life, admissions, and more.

**Base URL:** `https://api.penngpt.velroi.com`

## Features

- 🎓 **UPenn Community-Focused**: Specialized for University of Pennsylvania students, faculty, staff, alumni, and prospective students
- 🗓️ **Current & Time-Aware**: Responses include current date context (September 21, 2025) for relevant events and deadlines
- 🔍 **Semantic Search**: Advanced vector search through comprehensive UPenn content
- 📚 **Detailed Source Citations**: All responses include ranked source citations with URLs
- 📝 **Comprehensive Answers**: Provides detailed dates, times, locations, contact information, and deadlines when available
- 💬 **Multi-turn Conversations**: Supports conversation context and follow-up questions
- 🚀 **High Performance**: Sub-3 second response times with reliable uptime
- 🌐 **CORS Enabled**: Ready for web application integration

---

## Authentication

**No authentication required.** The API is publicly accessible.

---

## Enhanced Response Format

The API is designed to provide **comprehensive, detailed answers** with:

- **Current Date Context**: All responses are aware that today is Saturday, September 21, 2025 (Eastern Time)
- **Specific Dates & Times**: When discussing events, deadlines, or schedules, responses include exact dates and times
- **Detailed Information**: Comprehensive answers with names, locations, contact details, and registration information
- **UPenn Community Focus**: All responses consider the context of students, faculty, staff, alumni, and prospective students
- **Structured Formatting**: Complex information is presented in tables, lists, and organized sections for clarity

---

## Privacy & Conversation Logging

The API implements **privacy-preserving conversation logging** for analytics and improvement purposes:

### **Privacy Protection:**
- **IP Address Hashing**: Client IPs are combined with user agents and salted, then hashed to create anonymous user identifiers
- **Content Sanitization**: Potential PII is detected and flagged (but preserved for functionality)
- **Session Isolation**: Each conversation session gets a unique ID for tracking without user identification
- **No Personal Data Storage**: No personally identifiable information is stored in raw form

### **Session Tracking:**
- Provide a `session_id` in requests to maintain conversation context across multiple API calls
- If no `session_id` is provided, a new one is automatically generated
- Session IDs help track multi-turn conversations while preserving privacy

### **Data Usage:**
- Logged conversations help improve AI responses and system performance
- Analytics data is used to understand usage patterns and optimize the service
- All data handling follows privacy-first principles

---

## Endpoints

### GET /health

Check API health and availability.

**Response:**
```json
{
  "status": "ok"
}
```

**Example:**
```bash
curl https://api.penngpt.velroi.com/health
```

### GET /stats/daily

Get daily conversation statistics including total conversations, unique users, and usage metrics.

**Response:**
```json
{
  "stats": {
    "total_conversations": 15,
    "unique_sessions_count": 8,
    "unique_users_count": 5,
    "total_messages": 42,
    "avg_messages_per_conversation": 2.8
  }
}
```

**Example:**
```bash
curl https://api.penngpt.velroi.com/stats/daily
```

### GET /stats/session/{session_id}

Get statistics for a specific conversation session.

**Response:**
```json
{
  "session_id": "256e9ebb-013b-475d-979d-ef5e1b973fe6",
  "stats": {
    "turn_count": 3,
    "total_messages": 6,
    "first_interaction": "2025-09-21T10:04:46.831000",
    "last_interaction": "2025-09-21T10:05:05.452000"
  }
}
```

**Example:**
```bash
curl https://api.penngpt.velroi.com/stats/session/YOUR_SESSION_ID
```

### GET /stats/quality

Get response quality and usefulness analytics to evaluate AI performance on real-world questions.

**Response:**
```json
{
  "stats": {
    "total_responses": 25,
    "responses_with_citations": 18,
    "helpful_responses": 15,
    "citation_rate": 0.72,
    "helpfulness_rate": 0.60,
    "avg_word_count": 342.5,
    "avg_citations": 3.2,
    "question_type_breakdown": {
      "dining": 8,
      "library_academic": 6,
      "hours_schedule": 5,
      "events_activities": 3,
      "housing": 2,
      "general": 1
    }
  }
}
```

**Response Fields:**
- `total_responses`: Total responses analyzed today
- `responses_with_citations`: Number of responses that included source citations
- `helpful_responses`: Responses classified as helpful (citations + substantial content)
- `citation_rate`: Percentage of responses with citations (0.0-1.0)
- `helpfulness_rate`: Percentage of responses classified as helpful (0.0-1.0)
- `avg_word_count`: Average word count of responses
- `avg_citations`: Average number of citations per response
- `question_type_breakdown`: Count of questions by category (dining, library, housing, etc.)

**Example:**
```bash
curl https://api.penngpt.velroi.com/stats/quality
```

### POST /chat

Submit a chat conversation and receive an AI-generated response with source citations.

**Request Body:**
```json
{
  "messages": [
    {
      "role": "user|assistant|system",
      "content": "string"
    }
  ],
  "top_k": 20,
  "max_doc_tokens": 10000,
  "session_id": "optional-session-id"
}
```

**Parameters:**
- `messages` *(required)*: Array of conversation messages in chronological order
  - `role`: Message sender - `"user"`, `"assistant"`, or `"system"`
  - `content`: Message text content
- `top_k` *(optional)*: Number of source documents to consider (1-50, default: 20)
- `max_doc_tokens` *(optional)*: Maximum tokens for document context (1000-50000, default: 10000)
- `session_id` *(optional)*: Session ID for conversation tracking and multi-turn context

**Response:**
```json
{
  "answer": "string",
  "citations": [
    {
      "rank": 1,
      "title": "string", 
      "url": "string",
      "path": "string"
    }
  ],
  "session_id": "generated-or-provided-session-id"
}
```

**Response Fields:**
- `answer`: AI-generated response to the user's query
- `citations`: Array of sources used, ranked by relevance
  - `rank`: Source ranking (1 = most relevant)
  - `title`: Document title
  - `url`: Source URL
  - `path`: Document path
- `session_id`: Unique session identifier for conversation tracking (generated if not provided)

---

## Usage Examples

### Basic Query
```bash
curl -X POST https://api.penngpt.velroi.com/chat \
  -H "Content-Type: application/json" \
  -d '{
    "messages": [
      {"role": "user", "content": "What dining options are available at Wharton?"}
    ]
  }'
```

### Multi-turn Conversation
```bash
curl -X POST https://api.penngpt.velroi.com/chat \
  -H "Content-Type: application/json" \
  -d '{
    "messages": [
      {"role": "user", "content": "What are the admission requirements for UPenn?"},
      {"role": "assistant", "content": "UPenn has competitive admission requirements including..."},
      {"role": "user", "content": "What about the application deadlines?"}
    ]
  }'
```

### Custom Parameters
```bash
curl -X POST https://api.penngpt.velroi.com/chat \
  -H "Content-Type: application/json" \
  -d '{
    "messages": [
      {"role": "user", "content": "Tell me about UPenn research opportunities"}
    ],
    "top_k": 15,
    "max_doc_tokens": 8000
  }'
```

---

## JavaScript/TypeScript Integration

### Fetch API
```javascript
const response = await fetch('https://api.penngpt.velroi.com/chat', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
  },
  body: JSON.stringify({
    messages: [
      { role: 'user', content: 'What study spaces are available at Penn?' }
    ],
    top_k: 20,
    max_doc_tokens: 10000
  })
});

const data = await response.json();
console.log('Answer:', data.answer);
console.log('Sources:', data.citations);
```

### Axios
```javascript
import axios from 'axios';

const response = await axios.post('https://api.penngpt.velroi.com/chat', {
  messages: [
    { role: 'user', content: 'How do I apply for housing at UPenn?' }
  ],
  top_k: 20,
  max_doc_tokens: 10000
});

console.log('Answer:', response.data.answer);
console.log('Citations:', response.data.citations);
```

### React Hook Example
```jsx
import { useState } from 'react';

function usePennGPT() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const askQuestion = async (question, conversationHistory = []) => {
    setLoading(true);
    setError(null);
    
    try {
      const messages = [
        ...conversationHistory,
        { role: 'user', content: question }
      ];
      
      const response = await fetch('https://api.penngpt.velroi.com/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages })
      });
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      return data;
    } catch (err) {
      setError(err.message);
      return null;
    } finally {
      setLoading(false);
    }
  };

  return { askQuestion, loading, error };
}
```

---

## Python Integration

### Requests Library
```python
import requests

def ask_penngpt(question, conversation_history=None):
    url = "https://api.penngpt.velroi.com/chat"
    
    messages = conversation_history or []
    messages.append({"role": "user", "content": question})
    
    payload = {
        "messages": messages,
        "top_k": 20,
        "max_doc_tokens": 10000
    }
    
    response = requests.post(url, json=payload)
    response.raise_for_status()
    
    return response.json()

# Example usage
result = ask_penngpt("What are the top research areas at UPenn?")
print("Answer:", result["answer"])
print("Sources:", len(result["citations"]), "citations found")
```

### Async Python
```python
import aiohttp
import asyncio

async def ask_penngpt_async(question, conversation_history=None):
    url = "https://api.penngpt.velroi.com/chat"
    
    messages = conversation_history or []
    messages.append({"role": "user", "content": question})
    
    payload = {
        "messages": messages,
        "top_k": 20,
        "max_doc_tokens": 10000
    }
    
    async with aiohttp.ClientSession() as session:
        async with session.post(url, json=payload) as response:
            response.raise_for_status()
            return await response.json()

# Example usage
async def main():
    result = await ask_penngpt_async("Tell me about UPenn's dining plans")
    print("Answer:", result["answer"])

asyncio.run(main())
```

---

## Error Handling

### HTTP Status Codes
- `200 OK`: Successful request
- `400 Bad Request`: Invalid request parameters
- `422 Unprocessable Entity`: Validation error
- `500 Internal Server Error`: Server error
- `503 Service Unavailable`: Service temporarily unavailable

### Error Response Format
```json
{
  "detail": "Error description"
}
```

### Example Error Handling
```javascript
try {
  const response = await fetch('https://api.penngpt.velroi.com/chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      messages: [{ role: 'user', content: 'Your question' }]
    })
  });
  
  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.detail || `HTTP ${response.status}`);
  }
  
  const data = await response.json();
  return data;
} catch (error) {
  console.error('PennGPT API Error:', error.message);
}
```

---

## Best Practices

### Performance Optimization
1. **Adjust `top_k`**: Use lower values (5-10) for faster responses when fewer sources are needed
2. **Manage `max_doc_tokens`**: Reduce for faster processing, increase for more comprehensive context
3. **Batch Questions**: Include conversation history to maintain context without separate requests

### Content Guidelines
1. **UPenn Focus**: The API is optimized for University of Pennsylvania related queries
2. **Specific Questions**: More specific questions yield better, more targeted responses
3. **Conversation Context**: Include previous messages for follow-up questions

### Rate Limiting
- No explicit rate limits currently enforced
- Please use the API responsibly to ensure availability for all users
- Consider implementing client-side throttling for high-volume applications

---

## Sample Queries

The API excels at answering questions about:

**Academics & Admissions:**
- "What are the admission requirements for Wharton School?"
- "How do I apply for graduate programs at Penn Engineering?"
- "What research opportunities are available for undergraduates?"

**Campus Life:**
- "What dining options are available on campus?"
- "Tell me about housing options for graduate students"
- "What study spaces are available in the libraries?"

**Services & Resources:**
- "How do I access Penn Libraries resources?"
- "What health services are available to students?"
- "Where can I find academic advising support?"

**Events & Activities:**
- "What events are happening at Penn this week?" *(Returns detailed schedule with dates, times, and locations)*
- "How do I get involved in student organizations?"
- "What recreational facilities are available?"

**Time-Sensitive Information:**
- "What are the application deadlines for Wharton MBA programs?" *(Returns detailed deadline tables with specific dates)*
- "When is the next registration period for classes?"
- "What dining hours are available this weekend?"

---

## Support

For technical issues or questions about the API:
- Check the `/health` endpoint to verify service availability
- Ensure your requests follow the documented format
- Review error messages for specific guidance

---

## API Specifications

- **Protocol**: HTTPS only
- **Content-Type**: `application/json`
- **CORS**: Enabled for all origins
- **SSL Certificate**: Valid Let's Encrypt certificate
- **Response Time**: Typically < 3 seconds
- **Availability**: 24/7 with > 99% uptime target

---

*This API is powered by advanced AI and vector search technology, specifically trained and optimized for University of Pennsylvania information.*
