import { chromium } from 'playwright';
import * as cheerio from 'cheerio';

/**
 * Enterprise Agora Scraper with robots.txt compliance and deep crawling
 * Based on successful $25M enterprise integration
 */
export class AgoraScraper {
  constructor(config = {}) {
    this.config = {
      respectRobots: true,
      crawlDelay: 1000,
      maxDepth: 3,
      maxPages: 100,
      timeout: 30000,
      userAgent: 'Enterprise-Scraper/2.0 (Agora; +https://github.com/enterprise/scraper)',
      javascriptEnabled: false,
      followRedirects: true,
      ...config
    };
    
    this.browser = null;
    this.robotsCache = new Map();
    this.stats = {
      totalPages: 0,
      successfulPages: 0,
      failedPages: 0,
      robotsBlocked: 0,
      uniqueUrls: new Set(),
      duplicateUrls: 0,
      processingTime: 0
    };
  }

  async initialize() {
    console.log('🚀 Initializing Agora Scraper...');
    this.browser = await chromium.launch({
      headless: true,
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',
        '--disable-web-security',
        '--disable-features=VizDisplayCompositor'
      ]
    });
    console.log('✅ Agora Scraper initialized');
  }

  async scrapeWithDepth(domain, startingPath = '/', maxDepth = 3, pathPatterns = [], excludePatterns = []) {
    const startTime = Date.now();
    console.log(`🔍 Starting deep scrape: ${domain}${startingPath} (depth: ${maxDepth})`);
    
    if (!this.browser) {
      await this.initialize();
    }

    const baseUrl = `https://${domain}`;
    const startUrl = baseUrl + startingPath;
    
    // Check robots.txt compliance
    const robotsInfo = await this.checkRobotsCompliance(domain);
    
    const results = [];
    const visitedUrls = new Set();
    const urlQueue = [{ url: startUrl, depth: 0, parentUrl: null }];
    
    while (urlQueue.length > 0 && results.length < this.config.maxPages) {
      const { url, depth, parentUrl } = urlQueue.shift();
      
      // Skip if already visited
      if (visitedUrls.has(url)) {
        this.stats.duplicateUrls++;
        continue;
      }
      
      // Skip if depth exceeded
      if (depth > maxDepth) {
        continue;
      }
      
      // Check robots.txt compliance
      if (this.config.respectRobots && !this.isUrlAllowed(url, robotsInfo)) {
        console.log(`🚫 Robots.txt blocked: ${url}`);
        this.stats.robotsBlocked++;
        continue;
      }
      
      // Check path patterns
      if (!this.matchesPathPatterns(url, pathPatterns, excludePatterns)) {
        continue;
      }
      
      visitedUrls.add(url);
      this.stats.uniqueUrls.add(url);
      
      try {
        console.log(`📄 Scraping (depth ${depth}): ${url}`);
        const pageResult = await this.scrapePage(url, depth, parentUrl);
        
        if (pageResult) {
          results.push(pageResult);
          this.stats.successfulPages++;
          
          // Extract links for deeper crawling
          if (depth < maxDepth && pageResult.links) {
            pageResult.links.forEach(link => {
              const absoluteUrl = this.resolveUrl(link, url);
              if (this.isValidUrl(absoluteUrl, domain) && !visitedUrls.has(absoluteUrl)) {
                urlQueue.push({ url: absoluteUrl, depth: depth + 1, parentUrl: url });
              }
            });
          }
        }
        
        // Respect crawl delay
        const crawlDelay = robotsInfo.crawlDelay || this.config.crawlDelay;
        await this.sleep(crawlDelay);
        
      } catch (error) {
        console.error(`❌ Failed to scrape ${url}:`, error.message);
        this.stats.failedPages++;
      }
    }
    
    this.stats.totalPages = results.length;
    this.stats.processingTime = Date.now() - startTime;
    
    console.log(`✅ Deep scrape completed: ${results.length} pages in ${this.stats.processingTime}ms`);
    return {
      results,
      stats: { ...this.stats, uniqueUrls: this.stats.uniqueUrls.size },
      robotsInfo
    };
  }

  async scrapePage(url, depth, parentUrl) {
    const page = await this.browser.newPage();
    
    try {
      await page.setUserAgent(this.config.userAgent);
      await page.setViewportSize({ width: 1920, height: 1080 });
      
      const response = await page.goto(url, {
        timeout: this.config.timeout,
        waitUntil: 'domcontentloaded'
      });
      
      if (!response || !response.ok()) {
        throw new Error(`HTTP ${response?.status()}: ${response?.statusText()}`);
      }
      
      const content = await page.content();
      const $ = cheerio.load(content);
      
      // Remove script and style elements
      $('script, style, nav, footer, .sidebar, .menu, .advertisement').remove();
      
      // Extract text content
      const textContent = $('body').text().replace(/\s+/g, ' ').trim();
      
      // Extract links
      const links = [];
      $('a[href]').each((_, element) => {
        const href = $(element).attr('href');
        if (href) links.push(href);
      });
      
      // Extract metadata
      const title = $('title').text().trim();
      const metaDescription = $('meta[name="description"]').attr('content') || '';
      const metaKeywords = $('meta[name="keywords"]').attr('content') || '';
      
      // Extract headings
      const headings = {
        h1: $('h1').map((_, el) => $(el).text().trim()).get(),
        h2: $('h2').map((_, el) => $(el).text().trim()).get(),
        h3: $('h3').map((_, el) => $(el).text().trim()).get()
      };
      
      return {
        url,
        title,
        content: textContent,
        rawHtml: content,
        statusCode: response.status(),
        contentLength: content.length,
        metaDescription,
        metaKeywords,
        crawlDepth: depth,
        parentUrl,
        links: links.slice(0, 100), // Limit links to prevent memory issues
        headings,
        extractedData: {
          wordCount: textContent.split(/\s+/).length,
          linkCount: links.length,
          imageCount: $('img').length,
          hasVideo: $('video, iframe[src*="youtube"], iframe[src*="vimeo"]').length > 0,
          language: $('html').attr('lang') || 'unknown'
        },
        processingTimeMs: Date.now()
      };
      
    } finally {
      await page.close();
    }
  }

  async checkRobotsCompliance(domain) {
    if (this.robotsCache.has(domain)) {
      return this.robotsCache.get(domain);
    }
    
    const robotsUrl = `https://${domain}/robots.txt`;
    const robotsInfo = {
      isAccessible: true,
      crawlDelay: this.config.crawlDelay,
      disallowed: [],
      sitemaps: []
    };
    
    try {
      const response = await fetch(robotsUrl, {
        headers: { 'User-Agent': this.config.userAgent }
      });
      
      if (response.ok) {
        const robotsText = await response.text();
        robotsInfo.content = robotsText;
        
        // Parse robots.txt
        const lines = robotsText.split('\n');
        let isRelevantSection = false;
        
        for (const line of lines) {
          const cleanLine = line.trim().toLowerCase();
          
          if (cleanLine.startsWith('user-agent:')) {
            const userAgent = cleanLine.split(':')[1]?.trim();
            isRelevantSection = userAgent === '*' || userAgent.includes('enterprise-scraper');
          } else if (isRelevantSection) {
            if (cleanLine.startsWith('disallow:')) {
              const path = cleanLine.split(':')[1]?.trim();
              if (path) robotsInfo.disallowed.push(path);
            } else if (cleanLine.startsWith('crawl-delay:')) {
              const delay = parseInt(cleanLine.split(':')[1]?.trim());
              if (!isNaN(delay)) robotsInfo.crawlDelay = delay * 1000; // Convert to ms
            }
          }
          
          if (cleanLine.startsWith('sitemap:')) {
            const sitemap = line.split(':').slice(1).join(':').trim();
            robotsInfo.sitemaps.push(sitemap);
          }
        }
      }
    } catch (error) {
      console.warn(`⚠️ Could not fetch robots.txt for ${domain}:`, error.message);
    }
    
    this.robotsCache.set(domain, robotsInfo);
    return robotsInfo;
  }

  isUrlAllowed(url, robotsInfo) {
    if (!robotsInfo.isAccessible) return false;
    
    const urlPath = new URL(url).pathname;
    return !robotsInfo.disallowed.some(disallowed => {
      if (disallowed === '/') return false; // Don't block everything
      return urlPath.startsWith(disallowed);
    });
  }

  matchesPathPatterns(url, includePatterns = [], excludePatterns = []) {
    const urlPath = new URL(url).pathname;
    
    // Check exclude patterns first
    if (excludePatterns.length > 0) {
      const isExcluded = excludePatterns.some(pattern => {
        if (pattern.includes('*')) {
          const regex = new RegExp('^' + pattern.replace(/\*/g, '.*') + '$');
          return regex.test(urlPath);
        }
        return urlPath.startsWith(pattern);
      });
      if (isExcluded) return false;
    }
    
    // Check include patterns
    if (includePatterns.length === 0) return true; // No patterns means include all
    
    return includePatterns.some(pattern => {
      if (pattern.includes('*')) {
        const regex = new RegExp('^' + pattern.replace(/\*/g, '.*') + '$');
        return regex.test(urlPath);
      }
      return urlPath.startsWith(pattern);
    });
  }

  resolveUrl(href, baseUrl) {
    try {
      return new URL(href, baseUrl).toString();
    } catch {
      return href;
    }
  }

  isValidUrl(url, domain) {
    try {
      const urlObj = new URL(url);
      return urlObj.hostname === domain || urlObj.hostname.endsWith(`.${domain}`);
    } catch {
      return false;
    }
  }

  async sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  async close() {
    if (this.browser) {
      await this.browser.close();
      this.browser = null;
    }
  }

  getStats() {
    return {
      ...this.stats,
      uniqueUrls: this.stats.uniqueUrls.size,
      averagePageSize: this.stats.successfulPages > 0 
        ? Math.round(this.stats.totalSize / this.stats.successfulPages) 
        : 0,
      successRate: this.stats.totalPages > 0 
        ? Math.round((this.stats.successfulPages / this.stats.totalPages) * 100) 
        : 0
    };
  }
}
