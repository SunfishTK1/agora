#!/usr/bin/env python3
"""
CLI demo for the UPenn Chat Assistant (Azure OpenAI + Milvus retrieval).

Usage:
  python chat_assistant_cli.py --query "What's happening at Wharton this week?" [--top-k 20] [--max-doc-tokens 10000]
"""
from __future__ import annotations

import os
import sys
import argparse
import json

from rag.chat_engine import ChatAssistant


def parse_args(argv):
    p = argparse.ArgumentParser(description="UPenn Chat Assistant CLI")
    p.add_argument("--query", "-q", required=True, help="User question")
    p.add_argument("--top-k", type=int, default=int(os.getenv("CHAT_DEFAULT_TOP_K", "20")))
    p.add_argument("--max-doc-tokens", type=int, default=int(os.getenv("CHAT_MAX_DOC_TOKENS", "10000")))
    return p.parse_args(argv)


def main(argv):
    args = parse_args(argv)
    assistant = ChatAssistant(
        milvus_db_path=os.getenv("MILVUS_DB_PATH", "./milvus_lite.db"),
        milvus_collection=os.getenv("MILVUS_COLLECTION_NAME", "web_documents"),
    )

    result = assistant.chat(
        user_messages=[{"role": "user", "content": args.query}],
        top_k=args.top_k,
        max_doc_tokens=args.max_doc_tokens,
    )

    print("\nAnswer:\n" + (result.get("answer") or ""))

    cits = result.get("citations", [])
    if cits:
        print("\nSources:")
        for c in cits:
            print(f"[{c.get('rank')}] {c.get('title') or ''} - {c.get('url') or ''} {c.get('path') or ''}")


if __name__ == "__main__":
    main(sys.argv[1:])
