import { cn } from '@shared/lib/utils'

interface ContainerProps {
  children: React.ReactNode
  className?: string
  size?: 'sm' | 'md' | 'lg' | 'xl' | 'full'
}

export function Container({ children, className, size = 'lg' }: ContainerProps) {
  const sizeClasses = {
    sm: 'max-w-3xl',
    md: 'max-w-5xl', 
    lg: 'max-w-7xl',
    xl: 'max-w-8xl',
    full: 'max-w-none'
  }

  return (
    <div className={cn('mx-auto px-6', sizeClasses[size], className)}>
      {children}
    </div>
  )
}
