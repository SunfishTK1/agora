import { cn } from '@shared/lib/utils'

export function Skeleton(props: React.HTMLAttributes<HTMLDivElement>) {
  return <div {...props} className={cn('animate-pulse rounded-md bg-muted', props.className)} />
}


