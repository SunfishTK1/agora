import { useI18n } from '../app/providers/I18nProvider'
import { useAuth } from '../app/providers/AuthProvider'
import { Link } from 'wouter'

export default function HomePage() {
  const { t } = useI18n()
  const { user, signIn, signOut } = useAuth()
  return (
    <div className="prose dark:prose-invert">
      <h1>{t('welcome')}</h1>
      <p>This is a starter SPA using React 18, Vite, Tailwind, and Wouter.</p>
      <div className="not-prose mt-4 flex items-center gap-3">
        {user ? (
          <>
            <span className="text-sm">Signed in as {user.name}</span>
            <button className="rounded-md border px-3 py-1 text-sm" onClick={signOut}>Sign out</button>
          </>
        ) : (
          <button className="rounded-md border px-3 py-1 text-sm" onClick={() => signIn('Student')}>Sign in</button>
        )}
      </div>
      <ul>
        <li><Link href="/forms">Forms demo</Link></li>
        <li><Link href="/markdown">Markdown demo</Link></li>
        <li><Link href="/charts">Charts demo</Link></li>
      </ul>
    </div>
  )
}


