import { Link, useLocation } from 'wouter'
import { Button } from '@shared/ui/button'
import { Container } from '@shared/ui/container'
import { useState, useRef, useEffect } from 'react'

// Optimized Mouse Trail Component with throttling
function MouseTrail() {
  const [trails, setTrails] = useState<Array<{id: number, x: number, y: number, timestamp: number}>>([])
  const lastUpdate = useRef(0)

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      const now = Date.now()
      // Throttle to 60fps max
      if (now - lastUpdate.current < 16) return
      
      lastUpdate.current = now
      const newTrail = {
        id: now + Math.random(),
        x: e.clientX,
        y: e.clientY,
        timestamp: now
      }
      
      setTrails(prev => [...prev.slice(-5), newTrail]) // Reduced to 5 trails for performance
    }

    document.addEventListener('mousemove', handleMouseMove, { passive: true })
    
    // Clean up old trails less frequently
    const cleanup = setInterval(() => {
      setTrails(prev => prev.filter(trail => Date.now() - trail.timestamp < 800))
    }, 200)

    return () => {
      document.removeEventListener('mousemove', handleMouseMove)
      clearInterval(cleanup)
    }
  }, [])

  return (
    <div className="fixed inset-0 pointer-events-none z-50">
      {trails.map((trail, index) => (
        <div
          key={trail.id}
          className="absolute w-1.5 h-1.5 bg-blue-400/60 rounded-full animate-ping"
          style={{
            left: trail.x - 3,
            top: trail.y - 3,
            opacity: (index + 1) / trails.length * 0.4,
            animationDuration: '0.4s'
          }}
        />
      ))}
    </div>
  )
}

// Optimized Floating Particles Component
function FloatingParticles() {
  const [particles, setParticles] = useState<Array<{id: number, x: number, y: number, size: number, opacity: number}>>([])

  useEffect(() => {
    // Reduced particle count for better performance
    const particleCount = 20
    const newParticles = Array.from({ length: particleCount }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: Math.random() * 2 + 1,
      opacity: Math.random() * 0.4 + 0.1
    }))
    setParticles(newParticles)
  }, [])

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden">
      {particles.map((particle) => (
        <div
          key={particle.id}
          className="absolute rounded-full bg-blue-400/30 animate-float"
          style={{
            left: `${particle.x}%`,
            top: `${particle.y}%`,
            width: `${particle.size}px`,
            height: `${particle.size}px`,
            opacity: particle.opacity,
            animationDelay: `${particle.id * 0.5}s`
          }}
        />
      ))}
    </div>
  )
}

export default function LandingPage() {
  const [query, setQuery] = useState('')
  const [isTyping, setIsTyping] = useState(false)
  const [, setLocation] = useLocation()
  const inputRef = useRef<HTMLInputElement>(null)
  const [displayedText, setDisplayedText] = useState('')
  const [showCursor, setShowCursor] = useState(true)
  const [titleComplete, setTitleComplete] = useState(false)
  const [terminalLines, setTerminalLines] = useState<string[]>([])
  const [currentTerminalLine, setCurrentTerminalLine] = useState(0)
  const [isTerminalBooting, setIsTerminalBooting] = useState(true)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (query.trim()) {
      // Store the query in localStorage so chat page can use it
      localStorage.setItem('agora-initial-query', query.trim())
      setLocation('/chat')
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleSubmit(e)
    }
  }

  const handleLearnMore = () => {
    // Smooth scroll to the terminal section
    const terminalElement = document.getElementById('terminal-demo')
    if (terminalElement) {
      terminalElement.scrollIntoView({ 
        behavior: 'smooth',
        block: 'center'
      })
    }
  }

  useEffect(() => {
    // Focus the input when component mounts
    if (inputRef.current) {
      inputRef.current.focus()
    }
  }, [])

  // Typing effect for the main heading (no glitch)
  useEffect(() => {
    const fullText = "Your Organization's Knowledge, All in One Place"
    let currentIndex = 0
    
    const typeText = () => {
      if (currentIndex < fullText.length) {
        setDisplayedText(fullText.slice(0, currentIndex + 1))
        currentIndex++
        setTimeout(typeText, 50) // Typing speed
      } else {
        // Title typing is complete
        setTitleComplete(true)
        // Hide cursor after a brief delay
        setTimeout(() => {
          setShowCursor(false)
        }, 1000)
      }
    }
    
    // Start typing after a brief delay
    const startDelay = setTimeout(() => {
      typeText()
    }, 800)
    
    return () => clearTimeout(startDelay)
  }, [])

  // Cursor blinking effect (only while title is typing)
  useEffect(() => {
    if (titleComplete) return // Don't start blinking if title is already complete
    
    const cursorInterval = setInterval(() => {
      setShowCursor(prev => !prev)
    }, 500)
    
    return () => clearInterval(cursorInterval)
  }, [titleComplete])

  // Terminal boot sequence animation (starts after title is complete)
  useEffect(() => {
    if (!titleComplete) return // Wait for title to complete
    
    const bootSequence = [
      "AGORA Terminal v2.0 - Initializing...",
      "Loading neural networks... ████████████████ 100%",
      "Connecting to knowledge base... ████████████████ 100%",
      "AI systems ready... ████████████████ 100%",
      "Welcome to AGORA - Your AI Knowledge Assistant"
    ]

    let currentIndex = 0
    const typeBootLine = () => {
      if (currentIndex < bootSequence.length) {
        const line = bootSequence[currentIndex]
        let charIndex = 0
        let currentLine = ""
        
        const typeChar = () => {
          if (charIndex < line.length) {
            currentLine += line[charIndex]
            setTerminalLines(prev => {
              const newLines = [...prev]
              newLines[currentIndex] = currentLine
              return newLines
            })
            charIndex++
            setTimeout(typeChar, Math.random() * 30 + 10) // Variable typing speed
          } else {
            currentIndex++
            setTimeout(typeBootLine, 500) // Pause between lines
          }
        }
        
        // Add empty line first
        setTerminalLines(prev => {
          const newLines = [...prev]
          newLines[currentIndex] = ""
          return newLines
        })
        
        setTimeout(typeChar, 100)
      } else {
        setIsTerminalBooting(false)
        // After terminal boot completes, scroll to terminal and focus input
        setTimeout(() => {
          // Smooth scroll to terminal
          const terminalElement = document.getElementById('terminal-demo')
          if (terminalElement) {
            terminalElement.scrollIntoView({ 
              behavior: 'smooth', 
              block: 'center' 
            })
          }
          // Focus the input after scrolling
          setTimeout(() => {
            if (inputRef.current) {
              inputRef.current.focus()
            }
          }, 800) // Wait for scroll to complete
        }, 1000) // Small delay after boot sequence
      }
    }

    // Start boot sequence after title completes (with a small delay)
    const bootDelay = setTimeout(() => {
      typeBootLine()
    }, 1500) // 1.5 second delay after title completion

    return () => clearTimeout(bootDelay)
  }, [titleComplete]) // Depend on titleComplete

  return (
    <div className="min-h-screen app-gradient text-brand dark:text-white relative overflow-hidden">
      {/* Futuristic Animation Components */}
      <FloatingParticles />
      <MouseTrail />
      
      {/* Navigation */}
      <nav className="bg-background/80 backdrop-blur-sm sticky top-0 z-50" role="navigation" aria-label="Main navigation">
        <Container>
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <h1 className="text-lg font-semibold text-foreground dark:text-white tracking-tight">
                AGORA
              </h1>
            </div>
            <div className="flex items-center space-x-4">
              <Link href="/chat">
                <Button variant="default" size="sm">
                  Get Started
                </Button>
              </Link>
            </div>
          </div>
        </Container>
      </nav>

          {/* Hero Section */}
          <main className="relative overflow-hidden py-[4vh] md:py-[6vh] lg:py-[8vh]">
            <Container size="lg">
              <div className="text-center mobile-spacing">
                    <div className="inline-flex items-center gap-2 px-[1.5vw] md:px-4 py-2 rounded-full bg-background/20 backdrop-blur-sm text-[clamp(0.75rem,2vw,0.875rem)] font-medium text-foreground dark:text-white mb-[3vh] md:mb-[4vh] border border-border/20">
                      <span className="w-[0.5rem] h-[0.5rem] bg-accent rounded-full" aria-hidden="true"></span>
                      Introducing the future of knowledge management
                    </div>

                <h1 className="text-[clamp(2rem,7vw,4.5rem)] font-display font-bold tracking-tightest mb-[2vh] md:mb-[3vh] leading-tight min-h-[1.2em]">
                  <span className="inline-block">
                    {/* Clean typing text without glitch */}
                    <span className="text-foreground dark:text-white">
                      {displayedText.split(',').map((part, index) => (
                        <span key={index}>
                          {part}
                          {index === 0 && displayedText.includes(',') && ','}
                          {index === 0 && displayedText.includes(',') && <br />}
                        </span>
                      ))}
                    </span>
                    
                    {showCursor && (
                      <span className="animate-pulse text-blue-500 ml-1">|</span>
                    )}
                  </span>
                </h1>


                <div className="flex flex-col sm:flex-row gap-[2vw] md:gap-4 justify-center mobile-button-group mb-[6vh] md:mb-[8vh]">
                  <Link href="/chat">
                    <Button size="lg" variant="default" className="min-h-[clamp(44px,5vh,56px)] px-[clamp(16px,3vw,24px)] text-[clamp(0.875rem,1.5vw,1rem)] w-full sm:w-auto">
                      Start Asking Questions
                    </Button>
                  </Link>
                  <Button 
                    size="lg" 
                    variant="outline" 
                    className="min-h-[clamp(44px,5vh,56px)] px-[clamp(16px,3vw,24px)] text-[clamp(0.875rem,1.5vw,1rem)] w-full sm:w-auto"
                    onClick={handleLearnMore}
                  >
                    Learn More
                  </Button>
                </div>

                {/* Computer Screen Mockup */}
                <div id="terminal-demo" className="relative mx-auto w-full max-w-[90vw] lg:max-w-4xl">
              <div className="relative bg-gray-900 dark:bg-gray-800 rounded-[clamp(12px,2vw,24px)] shadow-2xl overflow-hidden border border-gray-700 dark:border-gray-600">
                {/* Screen Header */}
                <div className="flex items-center justify-between bg-gray-800 dark:bg-gray-700 px-[clamp(12px,3vw,24px)] py-[clamp(8px,2vh,16px)] border-b border-gray-700 dark:border-gray-600">
                  <div className="flex items-center space-x-[clamp(4px,1vw,8px)]">
                    <div className="w-[clamp(8px,1.5vw,16px)] h-[clamp(8px,1.5vw,16px)] bg-red-500 rounded-full"></div>
                    <div className="w-[clamp(8px,1.5vw,16px)] h-[clamp(8px,1.5vw,16px)] bg-yellow-500 rounded-full"></div>
                    <div className="w-[clamp(8px,1.5vw,16px)] h-[clamp(8px,1.5vw,16px)] bg-green-500 rounded-full"></div>
                  </div>
                  <div className="text-gray-400 text-[clamp(0.75rem,2vw,1rem)] font-mono">AGORA Terminal v2.0</div>
                </div>

                {/* Terminal Content */}
                <div className="bg-black dark:bg-gray-900 p-[clamp(16px,4vw,32px)] font-mono text-[clamp(0.75rem,2vw,1rem)] relative overflow-hidden">
                  {/* CRT Scanlines Effect */}
                  <div className="absolute inset-0 pointer-events-none">
                    <div className="absolute inset-0 bg-gradient-to-b from-transparent via-green-500/5 to-transparent animate-scanlines"></div>
                  </div>
                  
                  <div className="space-y-[clamp(8px,2vh,16px)] relative z-10">
                    {/* Boot Sequence Animation */}
                    {isTerminalBooting ? (
                      <div className="space-y-2">
                        {terminalLines.map((line, index) => (
                          <div key={index} className="text-green-400 animate-terminal-glow">
                            {line}
                            {index === terminalLines.length - 1 && (
                              <span className="animate-pulse ml-1">█</span>
                            )}
                          </div>
                        ))}
                      </div>
                    ) : (
                      <>
                        {/* Static Terminal Content After Boot */}
                        <div className="flex items-center space-x-[clamp(4px,1vw,8px)] animate-fade-in">
                          <span className="text-green-400">user@agora:~$</span>
                          <span className="text-white">agora --init</span>
                        </div>
                        <div className="text-gray-400 ml-[clamp(12px,3vw,24px)] animate-fade-in" style={{animationDelay: '0.2s'}}>
                          Initializing AGORA knowledge engine...
                        </div>
                        <div className="flex items-center space-x-[clamp(4px,1vw,8px)] animate-fade-in" style={{animationDelay: '0.4s'}}>
                          <span className="text-green-400">user@agora:~$</span>
                          <span className="text-white">agora query "How many volunteer hours were logged this month?"</span>
                        </div>
                        <div className="text-blue-400 ml-[clamp(12px,3vw,24px)] animate-fade-in" style={{animationDelay: '0.6s'}}>
                          ✓ Connecting to volunteer portal, donation system, and event tracker
                        </div>
                        <div className="text-blue-400 ml-[clamp(12px,3vw,24px)] animate-fade-in" style={{animationDelay: '0.8s'}}>
                          ✓ Aggregating data from 5 different web services
                        </div>
                        <div className="text-blue-400 ml-[clamp(12px,3vw,24px)] animate-fade-in" style={{animationDelay: '1.0s'}}>
                          ✓ Generating insights...
                        </div>
                        <div className="text-white ml-[clamp(12px,3vw,24px)] mt-[clamp(8px,2vh,16px)] p-[clamp(8px,2vw,16px)] bg-gray-800 dark:bg-gray-700 rounded border-l-[clamp(2px,0.5vw,4px)] border-blue-500 animate-fade-in" style={{animationDelay: '1.2s'}}>
                          Found volunteer data across multiple systems:<br/>
                          • Volunteer portal: 342 hours logged<br/>
                          • Event check-ins: 89 hours from community events<br/>
                          • Total this month: 431 volunteer hours (+23% vs last month)
                        </div>
                        <form onSubmit={handleSubmit} className="flex items-center space-x-[clamp(4px,1vw,8px)] animate-fade-in" style={{animationDelay: '1.4s'}}>
                          <span className="text-green-400">user@agora:~$</span>
                          <input
                            ref={inputRef}
                            type="text"
                            value={query}
                            onChange={(e) => setQuery(e.target.value)}
                            onKeyDown={handleKeyDown}
                            placeholder="Type your question here..."
                            className="bg-transparent text-white outline-none flex-1 font-mono text-[clamp(0.75rem,2vw,1rem)] placeholder-gray-500"
                            style={{ caretColor: 'white' }}
                          />
                          <span className="text-white animate-pulse">|</span>
                        </form>
                      </>
                    )}
                  </div>
                </div>
              </div>

              {/* Glow Effect */}
              <div className="absolute inset-0 bg-gradient-to-r from-blue-500/20 via-purple-500/20 to-pink-500/20 rounded-[clamp(12px,2vw,24px)] blur-[clamp(16px,3vw,32px)] -z-10"></div>
            </div>
          </div>
        </Container>

        {/* Subtle Background Elements */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none" aria-hidden="true">
          <div className="absolute top-1/4 left-1/4 w-[clamp(200px,30vw,400px)] h-[clamp(200px,30vw,400px)] bg-accent-light/20 rounded-full blur-[clamp(48px,8vw,96px)]"></div>
          <div className="absolute bottom-1/4 right-1/4 w-[clamp(200px,30vw,400px)] h-[clamp(200px,30vw,400px)] bg-accent-soft/20 rounded-full blur-[clamp(48px,8vw,96px)]"></div>
        </div>
      </main>

    </div>
  )
}
