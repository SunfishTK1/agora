import { useEffect } from 'react'
import { Button } from '@shared/ui/button'
import { cn } from '@shared/lib/utils'
import { PanelLeftClose, Plus, Trash2, Home } from 'lucide-react'
import { Link } from 'wouter'
import { useChatStore } from '../store'

interface ChatSidebarProps {
  onToggleSidebar: () => void
}

export function ChatSidebar({ onToggleSidebar }: ChatSidebarProps) {
  const { conversations, openConversation, deleteConversation, newConversation } = useChatStore()
  
  const onOpen = (id: string) => {
    openConversation(id)
    // Focus input so user can continue immediately
    requestAnimationFrame(() => {
      document.querySelector<HTMLTextAreaElement>('textarea[data-chat-input]')?.focus()
    })
  }

  return (
    <aside className="flex h-full flex-col bg-gray-50 dark:bg-slate-900">
      <div className="flex items-center justify-between p-2">
        <button onClick={onToggleSidebar} aria-label="Close sidebar" className="p-2 hover:bg-transparent">
          <PanelLeftClose size={18} />
        </button>
        <button onClick={newConversation} className="p-2 hover:bg-transparent flex items-center gap-1 text-sm">
          <Plus size={14} /> New chat
        </button>
      </div>
      <div className="flex-1 overflow-auto p-2">
        <nav aria-label="Conversation history">
          <ul className="space-y-1 text-sm" role="list">
            {conversations.map((c) => (
              <li key={c.id} className="group flex items-center justify-between gap-2 rounded-md px-2 py-1 hover:bg-transparent">
                <button 
                  className="truncate text-left" 
                  onClick={() => onOpen(c.id)}
                  aria-label={`Open conversation: ${c.title || 'Untitled'}`}
                >
                  {c.title || 'Untitled'}
                </button>
                <button 
                  className="invisible grid h-7 w-7 place-items-center rounded-md hover:bg-destructive hover:text-destructive-foreground group-hover:visible" 
                  onClick={() => deleteConversation(c.id)} 
                  aria-label={`Delete conversation: ${c.title || 'Untitled'}`}
                >
                  <Trash2 size={14} />
                </button>
              </li>
            ))}
          </ul>
        </nav>
      </div>
      <div className="p-2 pb-0">
        <Link href="/">
          <Button variant="secondary" size="sm" className="w-full rounded-t-lg gap-2">
            <Home size={14} />
            Back to Home
          </Button>
        </Link>
      </div>
    </aside>
  )
}
