import { useEffect, useRef } from 'react'
import { Textarea } from '@shared/ui/textarea'
import { Button } from '@shared/ui/button'
import { cn } from '@shared/lib/utils'
import { ArrowUp, Plus } from 'lucide-react'
import { useChatStore } from '../store'

interface ChatComposerProps {
  variant: 'default' | 'sticky'
}

export function ChatComposer({ variant }: ChatComposerProps) {
  const { input, setInput, send, sending, newConversation, messages } = useChatStore()
  const inputRef = useRef<HTMLTextAreaElement>(null)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    void send()
  }

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSubmit(e)
    }
  }

  useEffect(() => {
    if (!sending) {
      inputRef.current?.focus()
    }
  }, [sending])

  const InputRow = (
    <div className="flex justify-center items-end max-w-lg mx-auto md:max-w-2xl">
      <form onSubmit={handleSubmit} className="flex w-full items-center">
        <div className="relative flex-1">
          <Textarea
            ref={inputRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={sending ? 'Waiting for response...' : 'Ask a follow-up question...'}
            disabled={sending}
            rows={1}
            className={cn(
              "min-h-[48px] rounded-xl border-0 bg-background/80 backdrop-blur-sm shadow-agora text-sm text-foreground placeholder:text-muted-foreground focus:ring-2 focus:ring-brand/50 focus:bg-background/90 transition-all duration-200 resize-none text-left flex items-center justify-start py-3",
              messages.length > 1 ? "pl-14 pr-14" : "pr-14"
            )}
            data-chat-input
          />
          {/* New chat button inside the input (left side) */}
          {messages.length > 1 && (
            <button
              type="button"
              onClick={newConversation}
              className="absolute left-2 top-1/2 -translate-y-1/2 h-8 w-8 rounded-lg bg-background/50 hover:bg-background/80 shadow-sm hover:shadow-md transition-all duration-200 hover:scale-105 flex items-center justify-center"
            >
              <Plus size={16} />
            </button>
          )}
          {/* Send button inside the input (right side) */}
          <button
            type="submit"
            disabled={sending || !input.trim()}
            className="absolute right-2 top-1/2 -translate-y-1/2 h-8 w-8 rounded-lg bg-gradient-to-r from-brand to-brand-soft hover:from-brand-soft hover:to-brand shadow-agora hover:shadow-agora-lg transition-all duration-200 hover:scale-105 flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed text-white"
          >
            <ArrowUp size={16} className="text-white" />
          </button>
          {/* Subtle inner glow */}
          <div className="absolute inset-0 rounded-xl bg-gradient-to-r from-brand/5 via-transparent to-brand/5 pointer-events-none"></div>
        </div>
      </form>
    </div>
  )

  if (variant === 'inline') {
    return <div className="w-full px-4">{InputRow}</div>
  }
  
  return (
    <div className="w-full bg-gradient-to-t from-background via-background/70 to-transparent px-4 pt-2 pb-4 mobile-bottom-spacing">
      {InputRow}
      {variant === 'sticky' && (
        <div className="mt-3 text-center text-xs text-gray-500 dark:text-gray-400">Agora can make mistakes. Please verify important information.</div>
      )}
    </div>
  )
}
