import { Button } from '@shared/ui/button'
import { useChatStore } from '../store'

export function ChatWelcome() {
  const { setInput } = useChatStore()

  const handleQuestionClick = (question: string) => {
    setInput(question)
    // Focus the input after setting the value
    setTimeout(() => {
      const input = document.querySelector<HTMLTextAreaElement>('textarea[data-chat-input]')
      if (input) {
        input.focus()
      }
    }, 100)
  }

  return (
    <div className="flex flex-1 flex-col items-center justify-center gap-6 md:gap-8 px-4 md:px-6 text-center pb-24 mobile-spacing">
      <div className="w-16 h-16 bg-background/20 backdrop-blur-sm border-2 border-border rounded-xl flex items-center justify-center mb-4 md:mb-6">
        <div className="w-10 h-10 flex items-center justify-center">
          <div className="relative">
            {/* Penn Logo - Simplified version */}
            <div className="text-2xl font-bold text-red-600 dark:text-red-400">P</div>
            <div className="absolute -top-1 -right-1 w-2 h-2 bg-blue-600 dark:bg-blue-400 rounded-full"></div>
          </div>
        </div>
      </div>
      <h1 className="text-3xl md:text-4xl lg:text-5xl font-display font-bold text-foreground dark:text-white">Welcome to PennGPT</h1>
      <p className="max-w-2xl text-balance text-base md:text-lg text-foreground dark:text-white">
        Your intelligent University of Pennsylvania assistant. Ask anything about Penn's information, 
        get instant answers, and discover insights from our comprehensive knowledge base.
      </p>
      <div className="flex flex-wrap gap-2 md:gap-3 justify-center mt-4 md:mt-6 mobile-button-group" role="list" aria-label="Example questions">
        <Button 
          variant="glass" 
          size="sm" 
          className="w-64 h-16 cursor-pointer text-sm px-4 whitespace-normal leading-tight focus:outline-none focus:ring-2 focus:ring-brand transition-colors"
          onClick={() => handleQuestionClick("What events are happening this weekend?")}
          role="listitem"
          aria-label="Ask: What events are happening this weekend?"
          title="What events are happening this weekend?"
        >
          What events are happening this weekend?
        </Button>
        <Button 
          variant="glass" 
          size="sm" 
          className="w-64 h-16 cursor-pointer text-sm px-4 whitespace-normal leading-tight focus:outline-none focus:ring-2 focus:ring-brand transition-colors"
          onClick={() => handleQuestionClick("Where can I find free food on campus today?")}
          role="listitem"
          aria-label="Ask: Where can I find free food on campus today?"
          title="Where can I find free food on campus today?"
        >
          Where can I find free food on campus today?
        </Button>
        <Button 
          variant="glass" 
          size="sm" 
          className="w-64 h-16 cursor-pointer text-sm px-4 whitespace-normal leading-tight focus:outline-none focus:ring-2 focus:ring-brand transition-colors"
          onClick={() => handleQuestionClick("What's the best study spot near my dorm?")}
          role="listitem"
          aria-label="Ask: What's the best study spot near my dorm?"
          title="What's the best study spot near my dorm?"
        >
          What's the best study spot near my dorm?
        </Button>
      </div>
    </div>
  )
}
