export type Role = 'user' | 'assistant' | 'system'

export type Citation = {
  title: string
  url: string
  excerpt?: string
  rank?: number
  path?: string
}

export type Message = {
  id: string
  role: Role
  content: string
  createdAt: number
  citations?: Citation[]
}

export type Conversation = {
  id: string
  title: string
  createdAt: number
  updatedAt: number
  messages: Message[]
}

export type ChatStatus = 'idle' | 'sending' | 'error' | null

export type ChatState = {
  messages: Message[]
  input: string
  sending: boolean
  conversations: Conversation[]
  currentId: string | null
  sidebarOpen: boolean
  status: ChatStatus

  setInput: (value: string) => void
  newConversation: () => void
  openConversation: (id: string) => void
  deleteConversation: (id: string) => void
  toggleSidebar: () => void
  send: (prompt?: string) => Promise<void>
  reset: () => void
}


