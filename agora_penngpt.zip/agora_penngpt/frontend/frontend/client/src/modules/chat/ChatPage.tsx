import { useEffect, useRef, useState } from 'react'
import { Message } from './types'
import { Avatar, AvatarFallback } from '@shared/ui/avatar'
import { Button } from '@shared/ui/button'
import { Card, CardContent } from '@shared/ui/card'
import { cn } from '@shared/lib/utils'
import { ThumbsUp, ThumbsDown, Copy, PanelLeftOpen, RefreshCcw, Share2 } from 'lucide-react'
import ReactMarkdown from 'react-markdown'
import remarkGfm from 'remark-gfm'
import rehypeSanitize from 'rehype-sanitize'
import rehypeHighlight from 'rehype-highlight'
import { useChatStore } from './store'
import { ChatSidebar } from './components/ChatSidebar'
import { ChatComposer } from './components/ChatComposer'
import { ChatWelcome } from './components/ChatWelcome'

function WorkingOnItIndicator() {
  return (
    <div className="flex w-full justify-center px-2 sm:px-4" role="status" aria-live="polite">
      <div className="flex w-full max-w-3xl items-start gap-2 sm:gap-3">
        <Avatar className="flex-shrink-0">
          <AvatarFallback className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-600">
            <div className="text-lg font-bold text-red-600 dark:text-red-400">P</div>
          </AvatarFallback>
        </Avatar>
        <div className="max-w-2xl">
          <div className="w-full max-w-full rounded-xl px-3 py-2 sm:px-4 sm:py-3 bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-gray-800/60 dark:to-gray-700/60 border border-blue-200/50 dark:border-transparent text-gray-800 dark:text-white transition-all duration-200 font-sans shadow-sm">
            <div className="flex items-center gap-2 text-sm">
              <div className="flex space-x-1" aria-hidden="true">
                <div className="w-2 h-2 bg-gradient-to-r from-blue-500 to-indigo-500 dark:from-white dark:to-gray-200 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                <div className="w-2 h-2 bg-gradient-to-r from-blue-500 to-indigo-500 dark:from-white dark:to-gray-200 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                <div className="w-2 h-2 bg-gradient-to-r from-blue-500 to-indigo-500 dark:from-white dark:to-gray-200 rounded-full animate-bounce"></div>
              </div>
              <span className="text-gray-700 dark:text-white/80">Thinking...</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

function useAutoScroll(dep: number): React.RefObject<HTMLDivElement> {
  const ref = useRef<HTMLDivElement>(null)
  useEffect(() => {
    ref.current?.scrollTo({ top: ref.current.scrollHeight, behavior: 'smooth' })
  }, [dep])
  return ref
}

function useInputFocus() {
  const [isMobile, setIsMobile] = useState(false)
  
  useEffect(() => {
    const checkMobile = () => setIsMobile(window.innerWidth <= 768)
    checkMobile()
    window.addEventListener('resize', checkMobile)
    return () => window.removeEventListener('resize', checkMobile)
  }, [])

  useEffect(() => {
    if (!isMobile) return

    const handleFocus = () => {
        document.body.classList.add('mobile-input-focused')
      requestAnimationFrame(() => {
          window.scrollTo(0, document.body.scrollHeight)
      })
    }

    const handleBlur = () => {
      document.body.classList.remove('mobile-input-focused')
    }

    const input = document.querySelector('textarea[data-chat-input]')
    if (input) {
      input.addEventListener('focus', handleFocus)
      input.addEventListener('blur', handleBlur)

      return () => {
        input.removeEventListener('focus', handleFocus)
        input.removeEventListener('blur', handleBlur)
      }
    }
  }, [isMobile])
}

interface MessageBubbleProps {
  m: Message
}

function MessageBubble({ m }: MessageBubbleProps) {
  const isUser = m.role === 'user'
  const [showAllSources, setShowAllSources] = useState(false)
  
  // Determine if message is short (one-line) or long (multi-paragraph/elements)
  const isShortMessage = m.content.length < 100 && !m.content.includes('\n') && !m.content.includes('##') && !m.content.includes('- ')
  
  return (
    <div className={cn('flex w-full justify-center px-2 sm:px-4')}> 
      <div className={cn('flex w-full max-w-3xl items-start gap-2 sm:gap-3', isUser && 'flex-row-reverse')}> 
        {/* AI avatar on left, User avatar on right */}
        <Avatar className="flex-shrink-0">
          <AvatarFallback className={isUser ? "" : "bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-600"}>
            {isUser ? 'U' : (
              <div className="text-lg font-bold text-red-600 dark:text-red-400">P</div>
            )}
          </AvatarFallback>
        </Avatar>
        <div className={cn('min-w-0 flex-1', isUser ? 'flex flex-col items-end' : '')}> 
          <div className={cn(
            'rounded-xl break-words overflow-wrap-anywhere word-break transition-all duration-200 font-sans overflow-hidden',
            isShortMessage 
              ? 'px-3 py-2 sm:px-4 sm:py-3 leading-normal' 
              : 'px-4 py-4 sm:px-6 sm:py-5 leading-relaxed',
            isUser 
              ? 'bg-blue-50 dark:bg-gray-800/60 text-gray-900 dark:text-white max-w-lg font-normal' 
              : 'bg-white dark:bg-gray-800/60 text-gray-900 dark:text-white max-w-2xl shadow-sm font-normal'
          )}>
            <ReactMarkdown 
              remarkPlugins={[remarkGfm]} 
              rehypePlugins={[rehypeSanitize as any, rehypeHighlight as any]}
              components={{
                p: ({ children }) => <p className={cn("break-words overflow-wrap-anywhere text-gray-900 dark:text-white max-w-full text-base font-normal", isShortMessage ? "mb-0 leading-normal" : "mb-4 leading-relaxed")}>{children}</p>,
                pre: ({ children }) => <pre className="overflow-x-auto max-w-full text-gray-900 dark:text-white bg-gray-100 dark:bg-gray-900/50 p-4 rounded-lg my-4 text-sm font-mono">{children}</pre>,
                code: ({ children, ...props }) => 
                  <code className="break-all text-gray-900 dark:text-white bg-gray-100 dark:bg-gray-900/50 px-2 py-1 rounded text-sm font-mono" {...props}>{children}</code>,
                h1: ({ children }) => <h1 className="text-gray-900 dark:text-white font-semibold break-words max-w-full text-xl mb-4 mt-2">{children}</h1>,
                h2: ({ children }) => <h2 className="text-gray-900 dark:text-white font-medium break-words max-w-full text-lg mb-3 mt-2">{children}</h2>,
                h3: ({ children }) => <h3 className="text-gray-900 dark:text-white font-normal break-words max-w-full text-base mb-3 mt-2">{children}</h3>,
                li: ({ children }) => <li className="text-gray-900 dark:text-white break-words max-w-full mb-2 leading-relaxed font-normal">{children}</li>,
                ul: ({ children }) => <ul className="text-gray-900 dark:text-white max-w-full mb-4 pl-6 space-y-2 font-normal">{children}</ul>,
                ol: ({ children }) => <ol className="text-gray-900 dark:text-white max-w-full mb-4 pl-6 space-y-2 font-normal">{children}</ol>,
                strong: ({ children }) => <strong className="text-gray-900 dark:text-white font-semibold break-words">{children}</strong>,
                em: ({ children }) => <em className="text-gray-900 dark:text-white italic font-normal break-words">{children}</em>,
                a: ({ children, href, ...props }) => <a href={href} className="text-blue-600 dark:text-blue-300 hover:text-blue-800 dark:hover:text-blue-200 underline break-all transition-colors font-normal" target="_blank" rel="noopener noreferrer" {...props}>{children}</a>
              }}
            >
              {m.content}
            </ReactMarkdown>
          </div>
          {!isUser && (
            <div className="flex items-center gap-3 text-gray-500 dark:text-muted-foreground mt-4" role="toolbar" aria-label="Message actions"> 
              <button className="rounded p-2 hover:bg-gray-100 dark:hover:bg-accent focus:bg-gray-100 dark:focus:bg-accent focus:outline-none focus:ring-2 focus:ring-brand transition-colors" aria-label="Like this message" title="Like"><ThumbsUp size={16} /></button>
              <button className="rounded p-2 hover:bg-gray-100 dark:hover:bg-accent focus:bg-gray-100 dark:focus:bg-accent focus:outline-none focus:ring-2 focus:ring-brand transition-colors" aria-label="Dislike this message" title="Dislike"><ThumbsDown size={16} /></button>
              <button className="rounded p-2 hover:bg-gray-100 dark:hover:bg-accent focus:bg-gray-100 dark:focus:bg-accent focus:outline-none focus:ring-2 focus:ring-brand transition-colors" aria-label="Copy message to clipboard" title="Copy"><Copy size={16} /></button>
              <button className="rounded p-2 hover:bg-gray-100 dark:hover:bg-accent focus:bg-gray-100 dark:focus:bg-accent focus:outline-none focus:ring-2 focus:ring-brand transition-colors" aria-label="Regenerate this response" title="Regenerate"><RefreshCcw size={16} /></button>
              <button className="rounded p-2 hover:bg-gray-100 dark:hover:bg-accent focus:bg-gray-100 dark:focus:bg-accent focus:outline-none focus:ring-2 focus:ring-brand transition-colors" aria-label="Share this message" title="Share"><Share2 size={16} /></button>
            </div>
          )}
          {m.citations && m.citations.length > 0 && (
            <>
              <div className={cn('not-prose mt-3', isUser ? 'max-w-lg' : 'max-w-lg sm:max-w-lg')}>
                {/* Compact Sources Card */}
                <div className="relative bg-gradient-to-r from-blue-50/60 to-indigo-50/60 dark:from-blue-900/15 dark:to-indigo-900/15 backdrop-blur-sm border border-blue-200/40 dark:border-blue-800/40 rounded-lg p-2 sm:p-3 shadow-md">
                  {/* Compact Header */}
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 bg-blue-500 rounded-full flex items-center justify-center">
                        <svg className="w-2.5 h-2.5 text-white" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M12.586 4.586a2 2 0 112.828 2.828l-3 3a2 2 0 01-2.828 0 1 1 0 00-1.414 1.414 4 4 0 005.656 0l3-3a4 4 0 00-5.656-5.656l-1.5 1.5a1 1 0 101.414 1.414l1.5-1.5zm-5 5a2 2 0 012.828 0 1 1 0 101.414-1.414 4 4 0 00-5.656 0l-3 3a4 4 0 105.656 5.656l1.5-1.5a1 1 0 10-1.414-1.414l-1.5 1.5a2 2 0 11-2.828-2.828l3-3z" clipRule="evenodd" />
                        </svg>
                      </div>
                      <span className="text-xs font-medium text-blue-700 dark:text-blue-300">
                        Sources ({m.citations.length})
                      </span>
                    </div>
                    {m.citations.length > 3 && (
                      <button
                        onClick={() => setShowAllSources(true)}
                        className="text-xs text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-200 font-medium transition-colors"
                      >
                        +{m.citations.length - 3} more
                      </button>
                    )}
                  </div>

                  {/* Compact Sources List */}
                  <div className="space-y-1.5">
                    {m.citations.slice(0, 3).map((citation, index) => (
                      <a
                        key={index}
                        href={citation.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-2 p-1.5 rounded hover:bg-white/40 dark:hover:bg-white/10 transition-colors duration-150 group"
                      >
                        <div className="flex-shrink-0 w-5 h-5 bg-blue-100 dark:bg-blue-800/50 rounded-full flex items-center justify-center text-xs font-medium text-blue-600 dark:text-blue-400">
                          {citation.rank || index + 1}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="text-xs font-medium text-blue-800 dark:text-blue-200 group-hover:text-blue-900 dark:group-hover:text-blue-100 truncate">
                            {citation.title}
                          </div>
                        </div>
                        <svg className="w-3 h-3 text-blue-500 opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                        </svg>
                      </a>
                    ))}
                  </div>
                </div>
              </div>

              {/* Sources Modal */}
              {showAllSources && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4">
                  {/* Backdrop */}
                  <div 
                    className="absolute inset-0 bg-black/50 backdrop-blur-sm"
                    onClick={() => setShowAllSources(false)}
                  ></div>
                  
                  {/* Modal */}
                  <div className="relative bg-white dark:bg-gray-900 rounded-xl shadow-2xl max-w-2xl w-full max-h-[90vh] sm:max-h-[80vh] overflow-hidden mx-2 sm:mx-0">
                    {/* Modal Header */}
                    <div className="flex items-center justify-between p-4 sm:p-6 border-b border-gray-200 dark:border-gray-700">
                      <div className="flex items-center gap-2 sm:gap-3 min-w-0">
                        <div className="w-6 h-6 sm:w-8 sm:h-8 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0">
                          <svg className="w-3 h-3 sm:w-4 sm:h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M12.586 4.586a2 2 0 112.828 2.828l-3 3a2 2 0 01-2.828 0 1 1 0 00-1.414 1.414 4 4 0 005.656 0l3-3a4 4 0 00-5.656-5.656l-1.5 1.5a1 1 0 101.414 1.414l1.5-1.5zm-5 5a2 2 0 012.828 0 1 1 0 101.414-1.414 4 4 0 00-5.656 0l-3 3a4 4 0 105.656 5.656l1.5-1.5a1 1 0 10-1.414-1.414l-1.5 1.5a2 2 0 11-2.828-2.828l3-3z" clipRule="evenodd" />
                          </svg>
                        </div>
                        <h3 className="text-base sm:text-lg font-semibold text-gray-900 dark:text-white truncate">
                          All Sources ({m.citations.length})
                        </h3>
                      </div>
        <button
                        onClick={() => setShowAllSources(false)}
                        className="w-8 h-8 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 flex items-center justify-center transition-colors flex-shrink-0"
                      >
                        <svg className="w-5 h-5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                        </svg>
        </button>
      </div>
                    
                    {/* Modal Content */}
                    <div className="p-3 sm:p-6 overflow-y-auto max-h-[70vh] sm:max-h-[60vh]">
                      <div className="space-y-2 sm:space-y-3">
                        {m.citations.map((citation, index) => (
                          <a 
                            key={index}
                            href={citation.url} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="flex items-start gap-3 sm:gap-4 p-3 sm:p-4 rounded-lg border border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors duration-200 group"
                          >
                            <div className="flex-shrink-0 w-6 h-6 sm:w-8 sm:h-8 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center text-xs sm:text-sm font-medium text-blue-600 dark:text-blue-400">
                              {citation.rank || index + 1}
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="text-xs sm:text-sm font-medium text-gray-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 mb-1 break-words">
                                {citation.title}
                              </div>
                              {citation.path && (
                                <div className="text-xs text-gray-500 dark:text-gray-400 mb-2 break-words">
                                  {citation.path}
                                </div>
                              )}
                              <div className="text-xs text-blue-600 dark:text-blue-400 break-all">
                                {citation.url}
                              </div>
                            </div>
                            <div className="flex-shrink-0">
                              <svg className="w-4 h-4 sm:w-5 sm:h-5 text-gray-400 group-hover:text-blue-500 transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                              </svg>
                            </div>
                          </a>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  )
}



export default function ChatPage() {
  const { messages, sidebarOpen, toggleSidebar, newConversation, status, sending, send } = useChatStore()
  const scrollerRef = useAutoScroll(messages.length)
  const empty = messages.length === 0

  // Handle input focus behavior
  useInputFocus()

  // Auto-close sidebar on narrow screens (like split screen)
  useEffect(() => {
    const handleResize = () => {
      // Close sidebar if window is narrower than 1200px (split screen scenario)
      if (window.innerWidth < 1200 && sidebarOpen) {
        toggleSidebar()
      }
    }

    window.addEventListener('resize', handleResize)
    
    // Check initial size
    handleResize()

    return () => window.removeEventListener('resize', handleResize)
  }, [sidebarOpen, toggleSidebar])

  // Check for initial query from landing page
  useEffect(() => {
    const initialQuery = localStorage.getItem('agora-initial-query')
    if (initialQuery && empty) {
      // Clear the stored query
      localStorage.removeItem('agora-initial-query')
      // Send the initial query
      send(initialQuery)
    }
  }, [empty, send])
  return (
    <div className="relative min-h-screen app-gradient mobile-chat-container md:min-h-screen">
      <div className="flex min-h-screen w-full flex-row mobile-safe-area">
        {/* Sidebar: visible on mobile as overlay drawer when open, sticky column on desktop */}
        <div className={cn('md:sticky md:top-0 md:self-start md:h-screen md:transition-[width] md:duration-200', sidebarOpen ? 'md:w-64 lg:w-72 md:border-r' : 'md:w-10')}>
          {/* Desktop */}
          <div className="hidden h-full md:block">
            {sidebarOpen ? (
              <ChatSidebar onToggleSidebar={toggleSidebar} />
            ) : (
              <div className="flex h-full flex-col items-center p-1">
                <button 
                  onClick={toggleSidebar} 
                  aria-label="Open sidebar"
                  className="h-10 w-10 rounded-lg flex items-center justify-center text-muted-foreground hover:text-foreground transition-all duration-200 opacity-60 hover:opacity-100"
                >
                  <PanelLeftOpen size={18} />
                </button>
              </div>
            )}
          </div>
        </div>
        {/* Mobile drawer */}
        {sidebarOpen && (
          <div className="fixed inset-0 z-30 grid grid-cols-[80%_1fr] md:hidden">
            <div className="h-full bg-background shadow-xl mobile-sidebar-safe">
              <ChatSidebar onToggleSidebar={toggleSidebar} />
            </div>
            <button className="h-full w-full bg-black/20" onClick={toggleSidebar} aria-label="Close sidebar" />
          </div>
        )}
        <div className="flex min-h-screen flex-1 flex-col">
        {empty ? (
          <>
            <ChatWelcome />
            {/* Fixed bottom input for initial screen */}
            <div className={cn("fixed bottom-0 left-0 right-0 z-20 fixed-chat-input", sidebarOpen && "sidebar-open")}>
              <ChatComposer variant="sticky" />
            </div>
          </>
        ) : (
          <>
            <main ref={scrollerRef} className="flex-1 overflow-auto pb-24 mobile-messages-area" role="log" aria-live="polite" aria-label="Chat messages">
              <div className="mx-auto w-full max-w-2xl space-y-8 p-4 md:max-w-3xl md:p-6">
                {messages.map((m) => (
                  <MessageBubble key={m.id} m={m} />
                ))}
                {sending && <WorkingOnItIndicator />}
              </div>
            </main>

            {/* Fixed bottom input for both mobile and desktop */}
            <div className={cn("fixed bottom-0 left-0 right-0 z-20 fixed-chat-input", sidebarOpen && "sidebar-open")}>
              <ChatComposer variant="sticky" />
            </div>
          </>
        )}
        </div>
      </div>
    </div>
  )
}



