import { create } from 'zustand'
import { nanoid } from 'nanoid'
import { Conversation, Message, ChatState, ChatStatus, Citation } from './types'
import { chatWithPennGPT, checkPennGPTHealth, type PennGPTChatRequest, type PennGPTCitation } from '@/lib/api'

// PennGPT system prompt for University of Pennsylvania
const SYSTEM_PROMPT = `You are PennGPT, an intelligent assistant for the University of Pennsylvania.
- You specialize in providing accurate information about UPenn academics, campus life, admissions, and resources.
- You have access to comprehensive UPenn knowledge through advanced retrieval systems.
- Provide helpful, accurate responses about all aspects of the University of Pennsylvania.
- Be friendly, professional, and concise in your responses.
- When discussing courses, include course numbers and details when available.
- When discussing policies or information, cite relevant UPenn resources.
- Focus on practical, actionable information that helps students, faculty, and visitors.
`

function loadConversations(): Conversation[] {
  try {
    const raw = localStorage.getItem('penngpt_conversations')
    if (!raw) return []
    
    const parsed = JSON.parse(raw) as Conversation[]
    // Validate that parsed data has the expected structure
    if (Array.isArray(parsed)) {
      return parsed.filter(conv => 
        conv && 
        typeof conv.id === 'string' && 
        typeof conv.title === 'string' &&
        Array.isArray(conv.messages)
      )
    }
    return []
  } catch (error) {
    console.error('Failed to load conversations from localStorage:', error)
    return []
  }
}

function persist(conversations: Conversation[]) {
  try {
    localStorage.setItem('penngpt_conversations', JSON.stringify(conversations))
  } catch (error) {
    console.error('Failed to persist conversations to localStorage:', error)
  }
}

export const useChatStore = create<ChatState>((set, get) => ({
  messages: [],
  input: '',
  sending: false,
  conversations: loadConversations(),
  currentId: null,
  sidebarOpen: true,
  status: null as ChatStatus,
  setInput: (v) => set({ input: v }),
  toggleSidebar: () => set((s) => ({ sidebarOpen: !s.sidebarOpen })),

  newConversation: () => {
    const id = nanoid()
    const conv: Conversation = {
      id,
      title: 'New chat',
      createdAt: Date.now(),
      updatedAt: Date.now(),
      messages: [],
    }
    const conversations = [conv, ...get().conversations]
    persist(conversations)
    set({ conversations, currentId: id, messages: conv.messages, input: '' })
  },
  openConversation: (id) => {
    const conv = get().conversations.find((c) => c.id === id)
    if (!conv) return
    // ensure deep copy so editing won't mutate stored history until saved
    const restored = conv.messages.map((m) => ({ ...m }))
    set({ currentId: id, messages: restored, input: '' })
  },
  deleteConversation: (id) => {
    const conversations = get().conversations.filter((c) => c.id !== id)
    persist(conversations)
    const currentId = get().currentId === id ? null : get().currentId
    set({ conversations, currentId, messages: currentId ? get().messages : [] })
  },
  reset: () => set({ messages: [], input: '' }),
  send: async (prompt) => {
    const text = prompt ?? get().input.trim()
    if (!text) return

    const userMsg: Message = { id: nanoid(), role: 'user', content: text, createdAt: Date.now() }
    set((s) => ({ messages: [...s.messages, userMsg], input: '', sending: true, status: null }))

        try {
          set({ status: 'Thinking...' })

          // Collect conversation context (all messages except the current user message)
          const state = get()
          const conversationContext = state.messages
            .filter(msg => msg.id !== userMsg.id) // Exclude current user message
            .map(msg => ({
              role: msg.role,
              content: msg.content
            }))

          // Add system message at the beginning
          const messages = [
            { role: 'system' as const, content: SYSTEM_PROMPT },
            ...conversationContext,
            { role: 'user' as const, content: text }
          ]

          // Send message to PennGPT API
          const response = await chatWithPennGPT({
            messages,
            top_k: 20,
            max_doc_tokens: 10000
          })

          // Convert PennGPT citations to our format
          const citations: Citation[] = response.citations.map((citation: PennGPTCitation) => ({
            title: citation.title,
            url: citation.url,
            path: citation.path,
            rank: citation.rank
          }))

          const assistantMsg: Message = {
            id: nanoid(),
            role: 'assistant',
            content: response.answer,
            citations: citations.length > 0 ? citations : undefined,
            createdAt: Date.now()
          }

          set((s) => ({ messages: [...s.messages, assistantMsg], status: null }))

        // Save/update conversation
        const currentState = get()
        const firstUser = currentState.messages.find((m) => m.role === 'user')
        const title = firstUser ? firstUser.content.slice(0, 60) : 'New chat'
        let conversations = currentState.conversations.slice()
        let id = currentState.currentId

        if (!id) {
          id = nanoid()
          conversations = [
            { id, title, createdAt: Date.now(), updatedAt: Date.now(), messages: currentState.messages },
            ...conversations,
          ]
        } else {
          conversations = conversations.map((c) => (c.id === id ? { ...c, title, updatedAt: Date.now(), messages: currentState.messages } : c))
        }

        persist(conversations)
        set({ conversations, currentId: id })

    } catch (e: unknown) {
      // Only log in development
      if (import.meta.env.DEV) {
        console.error('Chat error:', e)
      }
      const errorMessage = (e as Error)?.message || 'Unknown error occurred'

      // Create an error message from the assistant
      const errorMsg: Message = {
        id: nanoid(),
        role: 'assistant',
        content: `❌ ${errorMessage}`,
        createdAt: Date.now()
      }

      set((s) => ({
        messages: [...s.messages, errorMsg],
        status: null
      }))

      // Show error toast
      if (typeof window !== 'undefined') {
        // Import toast dynamically to avoid circular dependencies
        import('@shared/components/Toast').then(({ useToast }) => {
          // This will be handled by the component that uses the store
        })
      }
    } finally {
      set({ sending: false })
    }
  },
}))


