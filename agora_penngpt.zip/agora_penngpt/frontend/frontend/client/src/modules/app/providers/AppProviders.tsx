import { AuthProvider } from './AuthProvider'
import { ThemeProvider } from './ThemeProvider'
import { I18nProvider } from './I18nProvider'
import { ToastProvider } from '@shared/components/Toast'

type Props = { children: React.ReactNode }

export function AppProviders({ children }: Props) {
  return (
    <ToastProvider>
      <ThemeProvider>
        <AuthProvider>
          <I18nProvider>{children}</I18nProvider>
        </AuthProvider>
      </ThemeProvider>
    </ToastProvider>
  )
}


