import { createContext, useContext, useMemo, useState } from 'react'

type Locale = 'en' | 'es'
type Dictionary = Record<string, string>

const dictionaries: Record<Locale, Dictionary> = {
  en: { greeting: 'Hello', welcome: 'Welcome to AGORA' },
  es: { greeting: 'Hola', welcome: 'Bienvenido a AGORA' },
}

type I18nContextValue = {
  locale: Locale
  t: (key: string) => string
  setLocale: (l: Locale) => void
}

const I18nContext = createContext<I18nContextValue | undefined>(undefined)

export function I18nProvider({ children }: { children: React.ReactNode }) {
  const [locale, setLocale] = useState<Locale>('en')
  const t = (key: string) => dictionaries[locale][key] ?? key

  const value = useMemo<I18nContextValue>(() => ({ locale, t, setLocale }), [locale])
  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>
}

export function useI18n() {
  const ctx = useContext(I18nContext)
  if (!ctx) throw new Error('useI18n must be used within I18nProvider')
  return ctx
}


