import { Link, useLocation } from 'wouter'
import { ThemeToggle } from '../providers/ThemeProvider'
import { cn } from '@shared/lib/utils'
import { Plus } from 'lucide-react'
import { useChatStore } from '../../chat/store'

type Props = { children: React.ReactNode }

function RailButton({ href, children, label, onClick }: { href?: string; children: React.ReactNode; label: string; onClick?: () => void }) {
  const className = cn('grid h-10 w-10 place-items-center rounded-lg bg-secondary hover:bg-secondary/80 transition-colors')
  return href ? (
    <Link href={href} className={className} aria-label={label}>
      {children}
    </Link>
  ) : (
    <button className={className} aria-label={label} type="button" onClick={onClick}>
      {children}
    </button>
  )
}

export function AppShell({ children }: Props) {
  const { toggleSidebar, newConversation } = useChatStore()
  const [location] = useLocation()
  const isLandingPage = location === '/'
  
  if (isLandingPage) {
    return <main className="min-h-screen">{children}</main>
  }
  
  return (
    <div className="min-h-screen">
      {/* Mobile header */}
      <header className="sticky top-0 z-20 flex items-center justify-between bg-background p-2 md:hidden border-b">
        <button onClick={toggleSidebar} className="grid h-10 w-10 place-items-center rounded-lg bg-secondary hover:bg-secondary/80 transition-colors" aria-label="Toggle sidebar">≡</button>
            <Link href="/" className="font-semibold">AGORA</Link>
        <ThemeToggle />
      </header>
      
      {/* Desktop layout */}
      <div className="md:flex md:min-h-[calc(100vh-0px)]">
        <aside className="sticky top-0 self-start z-10 hidden h-screen flex-col items-center gap-3 bg-gray-50 dark:bg-slate-900 p-2 border-r md:flex">
          <Link href="/" className="mb-2 mt-1 grid h-10 w-10 place-items-center rounded-lg bg-brand text-white text-[10px] leading-tight hover:bg-brand-soft transition-colors" aria-label="Home">
              AGORA
          </Link>
          <button onClick={toggleSidebar} className="grid h-10 w-10 place-items-center rounded-lg bg-secondary hover:bg-secondary/80 transition-colors" aria-label="Toggle sidebar">
            ≡
          </button>
          <RailButton label="New chat" onClick={newConversation}>
            <Plus size={18} />
          </RailButton>
          <ThemeToggle />
        </aside>
        <main className="flex-1 min-h-screen">{children}</main>
      </div>
    </div>
  )
}


