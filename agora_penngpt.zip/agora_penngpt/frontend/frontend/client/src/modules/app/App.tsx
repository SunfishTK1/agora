import { Route, Switch } from 'wouter'
import { lazy, Suspense } from 'react'
import { AppProviders } from './providers/AppProviders'
import { AppShell } from './components/AppShell'
import { ErrorBoundary } from '@shared/components/ErrorBoundary'

const LandingPage = lazy(() => import('../home/LandingPage'))
const ChatPage = lazy(() => import('../chat/ChatPage'))

export default function App() {
  return (
    <ErrorBoundary>
      <AppProviders>
        <AppShell>
          <Suspense fallback={
            <div className="flex items-center justify-center min-h-screen app-gradient">
              <div className="w-12 h-12 bg-gradient-to-r from-brand to-brand-soft rounded-2xl animate-pulse shadow-medium"></div>
            </div>
          }>
            <div className="page-transition">
              <Switch>
                <Route path="/" component={LandingPage} />
                <Route path="/chat" component={ChatPage} />
                <Route>404 – Not found</Route>
              </Switch>
            </div>
          </Suspense>
        </AppShell>
      </AppProviders>
    </ErrorBoundary>
  )
}


