import { createContext, useContext, useMemo, useState } from 'react'

export type User = { id: string; name: string } | null

type AuthContextValue = {
  user: User
  signIn: (name: string) => void
  signOut: () => void
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User>(null)

  const value = useMemo<AuthContextValue>(
    () => ({
      user,
      signIn: (name: string) => setUser({ id: 'demo', name }),
      signOut: () => setUser(null),
    }),
    [user]
  )

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used within AuthProvider')
  return ctx
}


