export type HttpMethod = 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE'

export type ApiOptions = {
  path: string
  method?: HttpMethod
  headers?: Record<string, string>
  query?: Record<string, string | number | boolean | undefined>
  body?: unknown
}

export async function api<TResponse>(options: ApiOptions): Promise<TResponse> {
  const { path, method = 'GET', headers, query, body } = options
  const url = new URL(path, window.location.origin)
  Object.entries(query ?? {}).forEach(([k, v]) => {
    if (v !== undefined) url.searchParams.set(k, String(v))
  })

  const res = await fetch(url, {
    method,
    headers: {
      'content-type': 'application/json',
      ...headers,
    },
    body: body ? JSON.stringify(body) : undefined,
  })

  if (!res.ok) {
    const text = await res.text().catch(() => '')
    throw new Error(`API error ${res.status}: ${text}`)
  }
  const contentType = res.headers.get('content-type') ?? ''
  if (contentType.includes('application/json')) {
    return res.json() as Promise<TResponse>
  }
  return (await res.text()) as unknown as TResponse
}

// PennGPT API Configuration - using local proxy to avoid mixed content issues
const PENNGPT_API_BASE = '/api'

export async function streamChat(body: unknown, onChunk: (delta: string) => void): Promise<void> {
  // PennGPT API doesn't support streaming, so we return the full response
  const res = await fetch(`${PENNGPT_API_BASE}/chat`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  })

  if (!res.ok) {
    const errorText = await res.text().catch(() => 'Unknown error')
    throw new Error(`PennGPT API error ${res.status}: ${errorText}`)
  }

  const data = await res.json()
  if (data.answer) {
    // Return full response instead of inefficient word-by-word simulation
    onChunk(data.answer)
  } else {
    throw new Error(data.detail || 'PennGPT API error')
  }
}

// Note: Knowledge functions are not available in direct FastAPI mode
// These would need to be implemented in the FastAPI server if needed
export type KnowledgeResult = { source: string; snippet: string; score: number }
export async function fetchKnowledge(query: string, k = 5): Promise<KnowledgeResult[]> {
  throw new Error('Knowledge search not available in direct FastAPI mode. Use the chat endpoint for course queries.')
}

export type KnowledgeGraph = {
  seeds: { id: string; label: string; text?: string; score?: number }[]
  nodes: { id: string; label: string; snippet: string }[]
  edges: { source: string; target: string; label?: string }[]
}
export async function fetchKnowledgeGraph(query: string, k = 5, depth = 3): Promise<KnowledgeGraph> {
  throw new Error('Knowledge graph not available in direct FastAPI mode. Use the chat endpoint for course queries.')
}

// Note: Advanced CMU tools are not available in direct FastAPI mode
// These would need to be implemented in the FastAPI server if needed
export async function cmuKnowledgeTool(query: string, k = 5, depth = 3): Promise<{ results: KnowledgeResult[]; graph: KnowledgeGraph; ragText: string }> {
  throw new Error('CMU knowledge tool not available in direct FastAPI mode. Use the chat endpoint for course queries.')
}

export type StructuredKnowledgeResponse = {
  queries: string[]
  perQuery: Array<{ query: string; ragText: string; results: KnowledgeResult[]; graph: KnowledgeGraph; ms: number }>
  merged: KnowledgeGraph
  results: KnowledgeResult[]
  facts: string[]
  metrics: { latencyMs: number; depthUsed: number }
}

export async function cmuKnowledgeStructured(queries: string[], k = 5, depth = 3): Promise<StructuredKnowledgeResponse> {
  throw new Error('CMU structured knowledge not available in direct FastAPI mode. Use the chat endpoint for course queries.')
}

export async function fetchGraphStats(): Promise<{ nodes: number; edges: number }> {
  throw new Error('Graph stats not available in direct FastAPI mode.')
}

export async function searchGraphNodes(q: string, limit = 50): Promise<Array<{ id: string; label: string }>> {
  throw new Error('Graph search not available in direct FastAPI mode. Use the chat endpoint for course queries.')
}

export type DigGraph = { nodes: Array<Record<string, any>>; edges: Array<{ source: string; target: string; label?: string }> }
export async function cmuKnowledgeDig(seeds: string[], relationHints: string[] = ['prereq','cross','department','location','requirement'], depth = 3, maxNodes = 200): Promise<{ graph: DigGraph; seeds: string[] }> {
  throw new Error('CMU knowledge dig not available in direct FastAPI mode. Use the chat endpoint for course queries.')
}

// PennGPT Chat API Types
export type PennGPTMessage = {
  role: 'user' | 'assistant' | 'system'
  content: string
}

export type PennGPTChatRequest = {
  messages: PennGPTMessage[]
  top_k?: number
  max_doc_tokens?: number
}

export type PennGPTCitation = {
  rank: number
  title: string
  url: string
  path: string
}

export type PennGPTChatResponse = {
  answer: string
  citations: PennGPTCitation[]
}

export async function chatWithPennGPT(request: PennGPTChatRequest, retries = 2): Promise<PennGPTChatResponse> {
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      const res = await fetch(`${PENNGPT_API_BASE}/chat`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(request),
      })
      
      if (!res.ok) {
        const error = await res.text().catch(() => 'Unknown error')
        
        // Don't retry on client errors (4xx)
        if (res.status >= 400 && res.status < 500) {
          throw new Error(`PennGPT API error ${res.status}: ${error}`)
        }
        
        // Retry on server errors (5xx) if attempts remaining
        if (attempt < retries) {
          await new Promise(resolve => setTimeout(resolve, 1000 * (attempt + 1)))
          continue
        }
        
        throw new Error(`PennGPT API error ${res.status}: ${error}`)
      }
      
      const data = await res.json()
      return data
    } catch (error) {
      console.error(`PennGPT API Error (attempt ${attempt + 1}):`, error)
      
      // Don't retry on network errors if no attempts remaining
      if (attempt === retries) {
        throw error
      }
      
      // Wait before retry
      await new Promise(resolve => setTimeout(resolve, 1000 * (attempt + 1)))
    }
  }
  
  throw new Error('Max retries exceeded')
}

// PennGPT Health Check
export async function checkPennGPTHealth(): Promise<{ status: string }> {
  const res = await fetch(`${PENNGPT_API_BASE}/health`)
  if (!res.ok) throw new Error(`Health check failed: ${res.status}`)
  return res.json()
}

// Legacy compatibility - map old function names to new PennGPT API
export type MessageContext = PennGPTMessage
export type CourseChatRequest = {
  message: string
  conversation_history?: MessageContext[]
  reset_conversation?: boolean
}
export type CourseChatResponse = {
  response: string
  timestamp: string
  success: boolean
}

export async function chatWithCourseAssistant(request: CourseChatRequest): Promise<CourseChatResponse> {
  // Convert old format to new PennGPT format
  const messages: PennGPTMessage[] = []
  
  // Add conversation history
  if (request.conversation_history) {
    messages.push(...request.conversation_history)
  }
  
  // Add current message
  messages.push({ role: 'user', content: request.message })
  
  const pennGPTResponse = await chatWithPennGPT({ 
    messages,
    top_k: 20,
    max_doc_tokens: 10000
  })
  
  // Convert back to old format for compatibility
  return {
    response: pennGPTResponse.answer,
    timestamp: new Date().toISOString(),
    success: true
  }
}

export async function checkCourseAssistantHealth(): Promise<{ status: string; assistant: { name: string }; timestamp: string; message: string }> {
  const health = await checkPennGPTHealth()
  return {
    status: health.status,
    assistant: { name: 'PennGPT' },
    timestamp: new Date().toISOString(),
    message: 'PennGPT API is healthy'
  }
}


