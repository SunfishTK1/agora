#!/usr/bin/env python3
"""
Conversation Logger for PennGPT Chat Assistant API
- Logs conversations to MongoDB with privacy preservation
- Generates session IDs for conversation tracking
- Hashes user identifiers for privacy
"""
import os
import hashlib
import uuid
import re
from datetime import datetime, timezone
from typing import List, Dict, Optional, Any
import logging

try:
    from pymongo import MongoClient
    from pymongo.server_api import ServerApi
    from pymongo.errors import ConnectionFailure, OperationFailure
    MONGODB_AVAILABLE = True
except ImportError:
    MONGODB_AVAILABLE = False

logger = logging.getLogger(__name__)

class ConversationLogger:
    def __init__(self, connection_string: Optional[str] = None):
        """Initialize conversation logger with MongoDB connection."""
        self.client = None
        self.db = None
        self.collection = None
        self.enabled = False
        
        if not MONGODB_AVAILABLE:
            logger.warning("pymongo not available - conversation logging disabled")
            return
            
        # Use provided connection string or environment variable
        conn_str = connection_string or os.getenv("MONGODB_CONNECTION_STRING")
        if not conn_str:
            logger.warning("No MongoDB connection string provided - conversation logging disabled")
            return
            
        try:
            # Create MongoDB client with ServerApi and additional settings for Atlas
            self.client = MongoClient(
                conn_str, 
                server_api=ServerApi('1'),
                serverSelectionTimeoutMS=30000,  # 30 second timeout
                connectTimeoutMS=30000,
                socketTimeoutMS=0,  # No timeout for socket operations
                maxPoolSize=10,
                retryWrites=True
            )
            # Test connection with longer timeout
            self.client.admin.command('ping')
            
            self.db = self.client['penngpt_conversations']
            self.collection = self.db['chat_logs']
            
            # Create indexes for efficient querying
            self.collection.create_index("session_id")
            self.collection.create_index("timestamp")
            self.collection.create_index("user_hash")
            
            self.enabled = True
            logger.info("MongoDB conversation logging initialized successfully")
            
        except (ConnectionFailure, OperationFailure) as e:
            logger.error(f"Failed to connect to MongoDB: {e}")
            self.enabled = False
        except Exception as e:
            logger.error(f"Unexpected error initializing MongoDB: {e}")
            self.enabled = False
    
    def _generate_user_hash(self, client_ip: str, user_agent: str = "") -> str:
        """Generate privacy-preserving hash for user identification."""
        # Combine IP and user agent, then hash with salt
        salt = os.getenv("CONVERSATION_LOG_SALT", "penngpt_privacy_salt_2025")
        user_string = f"{client_ip}:{user_agent}:{salt}"
        return hashlib.sha256(user_string.encode()).hexdigest()[:16]
    
    def _generate_session_id(self) -> str:
        """Generate unique session ID."""
        return str(uuid.uuid4())
    
    def _analyze_response(self, answer: str, citations: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Analyze response quality and characteristics for usefulness assessment."""
        analysis = {
            "has_citations": len(citations) > 0,
            "citation_count": len(citations),
            "answer_word_count": len(answer.split()) if answer else 0,
            "contains_dates": bool(re.search(r'\b\d{1,2}[/\-\.]\d{1,2}[/\-\.]\d{2,4}\b|\b(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]* \d{1,2},? \d{4}\b', answer, re.IGNORECASE)) if answer else False,
            "contains_times": bool(re.search(r'\b\d{1,2}:\d{2}\s*(?:AM|PM|am|pm)\b', answer, re.IGNORECASE)) if answer else False,
            "contains_locations": bool(re.search(r'\b(?:Hall|Building|Street|Avenue|Room|Floor|Center|Library|Quad)\b', answer, re.IGNORECASE)) if answer else False,
            "contains_contact_info": bool(re.search(r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b|[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}', answer)) if answer else False,
            "appears_helpful": len(citations) > 0 and len(answer.split()) > 50 if answer else False,
            "question_type": self._classify_question_type(answer),
        }
        return analysis
    
    def _classify_question_type(self, answer: str) -> str:
        """Classify the type of question based on response content."""
        if not answer:
            return "unknown"
        
        answer_lower = answer.lower()
        
        # Define patterns for different question types
        if any(word in answer_lower for word in ["hours", "open", "close", "schedule", "time"]):
            return "hours_schedule"
        elif any(word in answer_lower for word in ["dining", "food", "restaurant", "cafe", "meal"]):
            return "dining"
        elif any(word in answer_lower for word in ["library", "study", "book", "research"]):
            return "library_academic"
        elif any(word in answer_lower for word in ["housing", "dorm", "residence", "apartment"]):
            return "housing"
        elif any(word in answer_lower for word in ["admission", "apply", "application", "deadline"]):
            return "admissions"
        elif any(word in answer_lower for word in ["event", "activity", "program", "workshop"]):
            return "events_activities"
        elif any(word in answer_lower for word in ["health", "medical", "counseling", "wellness"]):
            return "health_services"
        elif any(word in answer_lower for word in ["course", "class", "professor", "enrollment"]):
            return "academics"
        else:
            return "general"

    def _sanitize_message(self, message: Dict[str, Any]) -> Dict[str, Any]:
        """Sanitize message content to remove potential PII."""
        sanitized = {
            "role": message.get("role", "unknown"),
            "content_length": len(message.get("content", "")),
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
        
        # Store actual content but flag for potential PII review
        content = message.get("content", "")
        
        # Basic PII detection (can be enhanced)
        pii_indicators = [
            "@", "phone", "ssn", "social security", 
            "credit card", "password", "email"
        ]
        
        has_potential_pii = any(indicator in content.lower() for indicator in pii_indicators)
        
        sanitized.update({
            "content": content,
            "potential_pii_detected": has_potential_pii,
            "content_hash": hashlib.md5(content.encode()).hexdigest()[:8]
        })
        
        return sanitized
    
    def log_conversation(
        self, 
        messages: List[Dict[str, Any]], 
        response: Dict[str, Any],
        client_ip: str = "unknown",
        user_agent: str = "",
        session_id: Optional[str] = None,
        request_params: Optional[Dict[str, Any]] = None
    ) -> Optional[str]:
        """
        Log a conversation turn to MongoDB.
        
        Args:
            messages: List of conversation messages
            response: API response with answer and citations
            client_ip: Client IP address (will be hashed)
            user_agent: User agent string (will be hashed)
            session_id: Existing session ID or None to generate new one
            request_params: Request parameters (top_k, max_doc_tokens, etc.)
            
        Returns:
            Session ID for this conversation
        """
        if not self.enabled:
            return session_id
            
        try:
            # Generate session ID if not provided
            if not session_id:
                session_id = self._generate_session_id()
            
            # Create privacy-preserving user hash
            user_hash = self._generate_user_hash(client_ip, user_agent)
            
            # Sanitize messages
            sanitized_messages = [self._sanitize_message(msg) for msg in messages]
            
            # Prepare log entry
            log_entry = {
                "session_id": session_id,
                "user_hash": user_hash,
                "timestamp": datetime.now(timezone.utc),
                "messages": sanitized_messages,
                "response": {
                    "answer": response.get("answer", ""),
                    "answer_length": len(response.get("answer", "")),
                    "citations_count": len(response.get("citations", [])),
                    "answer_hash": hashlib.md5(response.get("answer", "").encode()).hexdigest()[:8],
                    "citations": response.get("citations", []),
                    "response_analysis": self._analyze_response(response.get("answer", ""), response.get("citations", []))
                },
                "request_params": request_params or {},
                "metadata": {
                    "api_version": "1.0.0",
                    "message_count": len(messages),
                    "total_characters": sum(len(msg.get("content", "")) for msg in messages)
                }
            }
            
            # Log to MongoDB
            result = self.collection.insert_one(log_entry)
            logger.info(f"Logged conversation to MongoDB for session {session_id}: {result.inserted_id}")
            
            return session_id
            
        except Exception as e:
            logger.error(f"Failed to log conversation: {e}")
            return session_id
    
    def get_session_stats(self, session_id: str) -> Optional[Dict[str, Any]]:
        """Get statistics for a conversation session."""
        if not self.enabled:
            return None
            
        try:
            pipeline = [
                {"$match": {"session_id": session_id}},
                {"$group": {
                    "_id": "$session_id",
                    "turn_count": {"$sum": 1},
                    "total_messages": {"$sum": "$metadata.message_count"},
                    "first_interaction": {"$min": "$timestamp"},
                    "last_interaction": {"$max": "$timestamp"}
                }}
            ]
            
            result = list(self.collection.aggregate(pipeline))
            return result[0] if result else None
            
        except Exception as e:
            logger.error(f"Failed to get session stats: {e}")
            return None
    
    def get_response_quality_stats(self) -> Optional[Dict[str, Any]]:
        """Get response quality and usefulness statistics."""
        if not self.enabled:
            return None
            
        try:
            today = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
            
            pipeline = [
                {"$match": {"timestamp": {"$gte": today}}},
                {"$group": {
                    "_id": None,
                    "total_responses": {"$sum": 1},
                    "responses_with_citations": {"$sum": {"$cond": ["$response.response_analysis.has_citations", 1, 0]}},
                    "helpful_responses": {"$sum": {"$cond": ["$response.response_analysis.appears_helpful", 1, 0]}},
                    "avg_word_count": {"$avg": "$response.response_analysis.answer_word_count"},
                    "avg_citations": {"$avg": "$response.response_analysis.citation_count"},
                    "question_types": {"$push": "$response.response_analysis.question_type"}
                }},
                {"$project": {
                    "total_responses": 1,
                    "responses_with_citations": 1,
                    "helpful_responses": 1,
                    "citation_rate": {"$divide": ["$responses_with_citations", "$total_responses"]},
                    "helpfulness_rate": {"$divide": ["$helpful_responses", "$total_responses"]},
                    "avg_word_count": {"$round": ["$avg_word_count", 1]},
                    "avg_citations": {"$round": ["$avg_citations", 1]},
                    "question_types": 1
                }}
            ]
            
            result = list(self.collection.aggregate(pipeline))
            if result:
                stats = result[0]
                # Count question types
                from collections import Counter
                question_type_counts = Counter(stats.get("question_types", []))
                stats["question_type_breakdown"] = dict(question_type_counts)
                stats.pop("question_types", None)
                return stats
            return {}
            
        except Exception as e:
            logger.error(f"Failed to get response quality stats: {e}")
            return None

    def get_daily_stats(self) -> Optional[Dict[str, Any]]:
        """Get daily conversation statistics."""
        if not self.enabled:
            return None
            
        try:
            today = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
            
            pipeline = [
                {"$match": {"timestamp": {"$gte": today}}},
                {"$group": {
                    "_id": None,
                    "total_conversations": {"$sum": 1},
                    "unique_sessions": {"$addToSet": "$session_id"},
                    "unique_users": {"$addToSet": "$user_hash"},
                    "total_messages": {"$sum": "$metadata.message_count"},
                    "avg_messages_per_conversation": {"$avg": "$metadata.message_count"}
                }},
                {"$project": {
                    "total_conversations": 1,
                    "unique_sessions_count": {"$size": "$unique_sessions"},
                    "unique_users_count": {"$size": "$unique_users"},
                    "total_messages": 1,
                    "avg_messages_per_conversation": {"$round": ["$avg_messages_per_conversation", 2]}
                }}
            ]
            
            result = list(self.collection.aggregate(pipeline))
            return result[0] if result else {}
            
        except Exception as e:
            logger.error(f"Failed to get daily stats: {e}")
            return None
    
    def close(self):
        """Close MongoDB connection."""
        if self.client:
            self.client.close()
            logger.info("MongoDB connection closed")


# Global conversation logger instance
_conversation_logger = None

def get_conversation_logger() -> ConversationLogger:
    """Get global conversation logger instance."""
    global _conversation_logger
    if _conversation_logger is None:
        connection_string = "mongodb+srv://sunfishtk_db_user:DVFcpbbGBKdWkiqL@penngpt-data.p3etwfl.mongodb.net/?retryWrites=true&w=majority&appName=PennGPT-Data"
        _conversation_logger = ConversationLogger(connection_string)
    return _conversation_logger
