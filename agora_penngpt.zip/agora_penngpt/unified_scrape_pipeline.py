#!/usr/bin/env python3
"""
Unified Scrape → Summarize → Embed → Store (Milvus Lite) Pipeline

- Highly concurrent recursive scraper restricted to a starting subdomain/subpath
- Saves raw page text and summaries to filesystem
- Summarizes each page to < 8000 tokens using Azure OpenAI
- Generates embeddings using Azure OpenAI embeddings
- Stores vectors and relational metadata in Milvus Lite

Usage:
    python unified_scrape_pipeline.py \
        --start-urls https://dine.cmu.edu/hours \
        --concurrency 100 \
        --max-pages 10000 \
        --collection-name web_documents \
        --scraped-dir ./scraped_data \
        --summaries-dir ./summaries \
        --milvus-db-path ./milvus_lite.db

Environment variables required:
    AZURE_OPENAI_API_KEY
    AZURE_OPENAI_ENDPOINT
    AZURE_OPENAI_API_VERSION
    AZURE_OPENAI_MODEL

    AZURE_OPENAI_EMBEDDING_API_KEY
    AZURE_OPENAI_EMBEDDING_ENDPOINT
    AZURE_OPENAI_EMBEDDING_API_VERSION
    AZURE_OPENAI_EMBEDDING_MODEL

Notes:
- This is a simplified, single-file pipeline designed for speed and reliability.
- Concurrency defaults to aggressive values; tune via --concurrency if needed.
"""

from __future__ import annotations

import asyncio
import argparse
import os
import re
import sys
import json
import time
import hashlib
import logging
import random
from dataclasses import dataclass
from typing import Optional, Set, Dict, List, Tuple
from urllib.parse import urlparse, urljoin, urldefrag

import httpx
from bs4 import BeautifulSoup
from dotenv import load_dotenv

# Azure OpenAI
try:
    from openai import AzureOpenAI
except Exception as e:
    raise RuntimeError("openai package missing or incompatible. Ensure openai>=1.0.0 is installed.") from e

# Token counting
import tiktoken

# Milvus Lite
from pymilvus import (
    connections,
    FieldSchema, CollectionSchema, DataType, Collection,
    utility
)

# ----------------------
# Configuration
# ----------------------
load_dotenv()

DEFAULT_SCRAPED_DIR = os.getenv("SCRAPED_DATA_DIR", "./scraped_data")
DEFAULT_SUMMARIES_DIR = os.getenv("SUMMARIES_DIR", "./summaries")
DEFAULT_MILVUS_DB_PATH = os.getenv("MILVUS_DB_PATH", "./milvus_lite.db")
DEFAULT_COLLECTION_NAME = os.getenv("MILVUS_COLLECTION_NAME", "web_documents")
DEFAULT_COOKIES_FILE = os.getenv("COOKIES_FILE", "./cookies.txt")

# Token/Embedding constraints
MAX_CONTEXT_TOKENS = int(os.getenv("MAX_CONTEXT_TOKENS", "120000"))
MAX_SUMMARY_TOKENS = int(os.getenv("MAX_SUMMARY_TOKENS", "8000"))
EMBEDDING_DIM = int(os.getenv("EMBEDDING_DIM", "3072"))

# Concurrency defaults
DEFAULT_CONCURRENCY = int(os.getenv("SCRAPER_CONCURRENCY", "100"))
AZURE_CONCURRENCY = int(os.getenv("AZURE_CONCURRENCY", "100"))
PER_HOST_LIMIT = int(os.getenv("PER_HOST_LIMIT", "8"))
JITTER_MIN_S = float(os.getenv("SCRAPER_JITTER_MIN_MS", "10")) / 1000.0
JITTER_MAX_S = float(os.getenv("SCRAPER_JITTER_MAX_MS", "50")) / 1000.0

# Logging setup
logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "INFO"),
    format="%(asctime)s - %(levelname)s - %(name)s - %(message)s",
)
logger = logging.getLogger("unified_pipeline")

# ----------------------
# Utilities
# ----------------------

def sha256_hex(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def safe_dirname_from_start_url(url: str) -> str:
    """Generate a filesystem-safe directory id from the start URL (netloc + path)."""
    p = urlparse(url)
    safe = (p.netloc + p.path).strip("/")
    safe = re.sub(r"[^a-zA-Z0-9._-]", "_", safe)
    return safe or "root"


def normalize_url(base: str, maybe_relative: str) -> Optional[str]:
    """Resolve relative links and drop fragments; return absolute URL or None if invalid."""
    if not maybe_relative:
        return None
    try:
        absu = urljoin(base, maybe_relative)
        absu, _ = urldefrag(absu)  # remove #fragment
        parsed = urlparse(absu)
        if parsed.scheme not in ("http", "https"):
            return None
        return absu
    except Exception:
        return None


def within_scope(url: str, base_netloc: str, base_path: str) -> bool:
    """Stay on same netloc and path prefix (subpath)."""
    p = urlparse(url)
    if p.netloc != base_netloc:
        return False
    # Normalize path: ensure leading '/'
    path = p.path or "/"
    if not base_path.endswith("/"):
        # Ensure strict subpath prefix semantics: '/hours' => '/hours' or '/hours/...'
        return path == base_path or path.startswith(base_path + "/")
    else:
        return path.startswith(base_path)


def looks_like_html(url: str) -> bool:
    """Heuristic to prefer HTML pages by extension."""
    path = urlparse(url).path.lower()
    if path.endswith((".png", ".jpg", ".jpeg", ".gif", ".svg", ".ico", ".webp", ".pdf", ".zip", ".rar", ".7z", ".mp4", ".mp3", ".wav", ".ppt", ".pptx", ".doc", ".docx", ".xls", ".xlsx", ".csv")):
        return False
    return True


def extract_text(html: str) -> Tuple[str, str]:
    """Return (title, visible_text)."""
    soup = BeautifulSoup(html, "lxml")
    # Remove script/style
    for tag in soup(["script", "style", "noscript", "template"]):
        tag.decompose()
    title = soup.title.string.strip() if soup.title and soup.title.string else ""
    text = soup.get_text(" ", strip=True)
    # Collapse excessive whitespace
    text = re.sub(r"\s+", " ", text).strip()
    return title, text


def load_netscape_cookies(path: str) -> Optional[httpx.Cookies]:
    """Load cookies from a Netscape cookies.txt file if present."""
    try:
        if not os.path.exists(path):
            return None
        jar = httpx.Cookies()
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                parts = line.split("\t")
                if len(parts) < 7:
                    parts = line.split()
                if len(parts) < 7:
                    continue
                domain, flag, cpath, secure, expiry, name, value = parts[:7]
                try:
                    jar.set(name, value, domain=domain, path=cpath)
                except Exception:
                    continue
        return jar
    except Exception as e:
        logger.debug(f"Failed to load cookies from {path}: {e}")
        return None


# ----------------------
# Optional Browser Fallback (Playwright)
# ----------------------
class BrowserFallback:
    def __init__(self, concurrency: int = 2) -> None:
        self._playwright = None
        self._browser = None
        self._context = None
        self._started = False
        self.semaphore = asyncio.Semaphore(max(1, concurrency))

    async def _ensure_started(self):
        if self._started:
            return
        try:
            from playwright.async_api import async_playwright  # type: ignore
        except Exception:
            logger.warning("Playwright not installed. Install with: pip install playwright && playwright install chromium")
            raise
        self._playwright = await async_playwright().start()
        self._browser = await self._playwright.chromium.launch(headless=True)
        self._context = await self._browser.new_context(
            user_agent=(
                "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36"
            ),
            viewport={"width": 1366, "height": 864},
        )
        self._started = True

    async def close(self):
        try:
            if self._context:
                await self._context.close()
            if self._browser:
                await self._browser.close()
            if self._playwright:
                await self._playwright.stop()
        except Exception:
            pass
        self._context = None
        self._browser = None
        self._playwright = None
        self._started = False

    async def fetch(self, url: str, referer: Optional[str]) -> Optional[str]:
        try:
            await self._ensure_started()
        except Exception:
            return None
        async with self.semaphore:
            page = await self._context.new_page()
            try:
                if referer:
                    await page.set_extra_http_headers({"Referer": referer})
                resp = await page.goto(url, wait_until="networkidle", timeout=25000)
                if not resp or resp.status != 200:
                    # Try a lighter wait condition
                    resp = await page.goto(url, wait_until="load", timeout=25000)
                    if not resp or resp.status != 200:
                        await page.close()
                        return None
                html = await page.content()
                await page.close()
                return html
            except Exception as e:
                try:
                    await page.close()
                except Exception:
                    pass
                logger.debug(f"Playwright fetch failed: {url} ({e})")
                return None


# ----------------------
# Azure Services
# ----------------------
class AzureSummarizer:
    def __init__(self, concurrency: int = AZURE_CONCURRENCY) -> None:
        api_key = os.environ["AZURE_OPENAI_API_KEY"]
        endpoint = os.environ["AZURE_OPENAI_ENDPOINT"]
        api_version = os.environ["AZURE_OPENAI_API_VERSION"]
        self.model = os.getenv("AZURE_OPENAI_MODEL", "gpt-5-chat")
        self.client = AzureOpenAI(api_key=api_key, azure_endpoint=endpoint, api_version=api_version)
        try:
            self.enc = tiktoken.encoding_for_model("gpt-4")
        except Exception:
            self.enc = tiktoken.get_encoding("cl100k_base")
        self.semaphore = asyncio.Semaphore(max(1, concurrency))

    def count_tokens(self, text: str) -> int:
        try:
            return len(self.enc.encode(text))
        except Exception:
            # Fallback conservative
            return max(1, len(text) // 4)

    async def _chat(self, content: str, max_tokens: int) -> str:
        def _call() -> str:
            resp = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": (
                        "You are an expert summarizer. Create an extremely dense and tightly written summary of the "
                        "following webpage content. Capture all critical details, facts, entities, and unique "
                        "insights that would be valuable for semantic search and embedding. The summary must be "
                        f"less than {MAX_SUMMARY_TOKENS} tokens."
                    )},
                    {"role": "user", "content": content},
                ],
                temperature=0.2,
                max_tokens=max_tokens,
            )
            return (resp.choices[0].message.content or "").strip()

        async with self.semaphore:
            return await asyncio.to_thread(_call)

    async def summarize(self, text: str) -> str:
        if not text.strip():
            return ""
        # If text exceeds model context, chunk it, summarize chunks, then synthesize
        token_count = self.count_tokens(text)
        if token_count <= MAX_CONTEXT_TOKENS - 1000:
            return await self._chat(text, max_tokens=min(MAX_SUMMARY_TOKENS - 50, 7900))
        # Chunking
        tokens = self.enc.encode(text)
        chunk_size = MAX_CONTEXT_TOKENS - 1500  # buffer for prompt/overhead
        chunks = []
        for i in range(0, len(tokens), chunk_size):
            chunks.append(self.enc.decode(tokens[i:i+chunk_size]))
        # Summarize each chunk concurrently
        partial_summaries = await asyncio.gather(*[self._chat(c, max_tokens=min(MAX_SUMMARY_TOKENS - 50, 7900)) for c in chunks])
        combined = "\n\n---\n\n".join(partial_summaries)
        if self.count_tokens(combined) > MAX_CONTEXT_TOKENS - 1000:
            # Summarize combined summaries again (recursive)
            return await self._chat(combined, max_tokens=min(MAX_SUMMARY_TOKENS - 50, 7900))
        # Final synthesis with a special system prompt
        def _final_call() -> str:
            resp = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": (
                        "You are a master synthesizer. Combine the following summaries into a single, dense, and "
                        "coherent summary. Retain all critical details, facts, and entities. The final output must "
                        "be optimized for text embedding and information retrieval."
                    )},
                    {"role": "user", "content": combined},
                ],
                temperature=0.2,
                max_tokens=min(MAX_SUMMARY_TOKENS - 50, 7900),
            )
            return (resp.choices[0].message.content or "").strip()
        async with self.semaphore:
            return await asyncio.to_thread(_final_call)


class AzureEmbedder:
    def __init__(self, concurrency: int = AZURE_CONCURRENCY) -> None:
        api_key = os.environ["AZURE_OPENAI_EMBEDDING_API_KEY"]
        endpoint = os.environ["AZURE_OPENAI_EMBEDDING_ENDPOINT"]
        api_version = os.environ["AZURE_OPENAI_EMBEDDING_API_VERSION"]
        self.model = os.getenv("AZURE_OPENAI_EMBEDDING_MODEL", "text-embedding-3-large")
        self.client = AzureOpenAI(api_key=api_key, azure_endpoint=endpoint, api_version=api_version)
        self.semaphore = asyncio.Semaphore(max(1, concurrency))

    async def embed(self, text: str) -> List[float]:
        if not text.strip():
            return []
        def _call() -> List[float]:
            resp = self.client.embeddings.create(
                model=self.model,
                input=text,
                dimensions=EMBEDDING_DIM,
            )
            return list(resp.data[0].embedding)
        async with self.semaphore:
            return await asyncio.to_thread(_call)


# ----------------------
# Milvus Lite Storage
# ----------------------
class MilvusStore:
    def __init__(self, db_path: str, collection_name: str) -> None:
        self.db_path = db_path
        self.collection_name = collection_name
        # Connect
        connections.connect(alias="default", uri=db_path)
        # Create collection if not exists
        if not utility.has_collection(self.collection_name):
            logger.info(f"Creating Milvus collection: {self.collection_name}")
            fields = [
                # String PK so we can use sha256(url) as id and overwrite by URL
                FieldSchema(name="id", dtype=DataType.VARCHAR, max_length=128, is_primary=True, auto_id=False),
                FieldSchema(name="url", dtype=DataType.VARCHAR, max_length=1024),
                FieldSchema(name="title", dtype=DataType.VARCHAR, max_length=512),
                FieldSchema(name="raw_path", dtype=DataType.VARCHAR, max_length=2048),
                FieldSchema(name="summary_path", dtype=DataType.VARCHAR, max_length=2048),
                FieldSchema(name="content_sha", dtype=DataType.VARCHAR, max_length=64),
                FieldSchema(name="summary_sha", dtype=DataType.VARCHAR, max_length=64),
                FieldSchema(name="embedding", dtype=DataType.FLOAT_VECTOR, dim=EMBEDDING_DIM),
            ]
            schema = CollectionSchema(fields=fields, description="Web documents with embeddings")
            self.collection = Collection(name=self.collection_name, schema=schema)
            # Create index for vector
            self.collection.create_index(
                field_name="embedding",
                index_params={
                    "index_type": "AUTOINDEX",
                    "metric_type": "COSINE",
                    "params": {}
                }
            )
            self.collection.load()
        else:
            self.collection = Collection(self.collection_name)
            # Some pymilvus versions don't expose has_index(); use indexes list
            if not getattr(self.collection, "indexes", None):
                self.collection.create_index(
                    field_name="embedding",
                    index_params={
                        "index_type": "AUTOINDEX",
                        "metric_type": "COSINE",
                        "params": {}
                    }
                )
            self.collection.load()

    def _record_id(self, url: str) -> str:
        return hashlib.sha256(url.encode("utf-8")).hexdigest()[:32]

    def insert(self, row: Dict) -> int:
        """Insert a single row dict into the current collection, adapting to schema."""
        # Common values
        url = row.get("url", "")
        title = row.get("title", "")
        raw_path = row.get("raw_path", "")
        summary_path = row.get("summary_path", "")
        content_sha = row.get("content_sha", "")
        summary_sha = row.get("summary_sha", "")
        summary_text = row.get("summary", "")
        try:
            up = urlparse(url)
            domain = up.netloc
            path = up.path or "/"
        except Exception:
            domain, path = "", ""

        # Load summary from file if not provided
        if not summary_text and summary_path and os.path.exists(summary_path):
            try:
                with open(summary_path, "r", encoding="utf-8") as f:
                    summary_text = f.read()
            except Exception:
                summary_text = ""

        # Normalize embedding length
        embedding = row.get("embedding", [])
        if not embedding:
            embedding = [0.0] * EMBEDDING_DIM
        elif len(embedding) != EMBEDDING_DIM:
            if len(embedding) > EMBEDDING_DIM:
                embedding = embedding[:EMBEDDING_DIM]
            else:
                embedding = embedding + [0.0] * (EMBEDDING_DIM - len(embedding))

        fields = self.collection.schema.fields  # type: ignore[attr-defined]
        columns: list[list] = []

        # Determine if this collection supports URL-based overwrite via string PK or url field
        has_id_varchar_pk = False
        has_url_field = False
        for f in fields:
            if getattr(f, "name", None) == "id" and getattr(f, "dtype", None) == DataType.VARCHAR and getattr(f, "is_primary", False) and not getattr(f, "auto_id", False):
                has_id_varchar_pk = True
            if getattr(f, "name", None) == "url":
                has_url_field = True

        # Overwrite semantics: remove existing doc by id(url) or by url before insert
        try:
            if has_id_varchar_pk:
                rid = self._record_id(url)
                self.collection.delete(f'id == "{rid}"')
            elif has_url_field:
                self.collection.delete(f'url == "{url}"')
            # flush not strictly necessary before insert, but keep it predictable
            self.collection.flush()
        except Exception:
            pass

        # Build column lists in schema order, skipping auto-id PK
        for f in fields:
            name = getattr(f, "name", None)
            dtype = getattr(f, "dtype", None)
            is_primary = getattr(f, "is_primary", False)
            auto_id = getattr(f, "auto_id", False)
            max_len = getattr(f, "max_length", None)

            if is_primary and auto_id:
                # Skip auto-increment field
                continue

            # Map values by name
            if name == "id":
                value = self._record_id(url)
            elif name == "url":
                value = url
            elif name == "title":
                value = title
            elif name == "raw_path":
                value = raw_path
            elif name == "summary_path":
                value = summary_path
            elif name in ("content_sha", "content_hash"):
                value = content_sha
            elif name == "summary_sha":
                value = summary_sha
            elif name == "summary":
                value = summary_text
            elif name == "domain":
                value = domain
            elif name == "path":
                value = path
            elif name == "embedding" and dtype == DataType.FLOAT_VECTOR:
                value = embedding
            elif name == "created_at" and dtype == DataType.DOUBLE:
                value = time.time()
            elif name == "metadata" and dtype == DataType.JSON:
                value = {
                    "raw_path": raw_path,
                    "summary_path": summary_path,
                    "model": os.getenv("AZURE_OPENAI_MODEL", "gpt-5-chat"),
                    "embedding_model": os.getenv("AZURE_OPENAI_EMBEDDING_MODEL", "text-embedding-3-large"),
                }
            else:
                # Unknown field: set empty/neutral
                if dtype == DataType.VARCHAR:
                    value = ""
                elif dtype == DataType.FLOAT_VECTOR:
                    value = [0.0] * EMBEDDING_DIM
                elif dtype == DataType.DOUBLE:
                    value = 0.0
                elif dtype == DataType.JSON:
                    value = {}
                else:
                    value = None

            # Truncate strings to max_len if necessary
            if isinstance(value, str) and max_len:
                value = value[:max_len]

            columns.append([value])

        mr = self.collection.insert(columns)
        self.collection.flush()
        # Return a stable id for logging: if string PK collection, use sha256(url).
        if has_id_varchar_pk:
            return self._record_id(url)
        # Otherwise, attempt to return server-reported PK; fall back to sha256(url) string
        try:
            if hasattr(mr, "primary_keys") and mr.primary_keys:
                return str(mr.primary_keys[0])
        except Exception:
            pass
        return self._record_id(url)


# ----------------------
# Scraper Orchestrator
# ----------------------
@dataclass
class PageItem:
    url: str
    title: str
    text: str


class Scraper:
    def __init__(
        self,
        start_urls: List[str],
        concurrency: int = DEFAULT_CONCURRENCY,
        max_pages: Optional[int] = None,
        scraped_dir: str = DEFAULT_SCRAPED_DIR,
        summaries_dir: str = DEFAULT_SUMMARIES_DIR,
        per_host_limit: int = PER_HOST_LIMIT,
        use_browser_fallback: bool = False,
        browser_concurrency: int = 2,
        cookies_file: Optional[str] = DEFAULT_COOKIES_FILE,
    ) -> None:
        self.start_urls = start_urls
        self.concurrency = max(1, concurrency)
        self.max_pages = max_pages
        self.scraped_dir = scraped_dir
        self.summaries_dir = summaries_dir
        self.per_host_limit = max(1, per_host_limit)
        self.use_browser_fallback = bool(use_browser_fallback)
        self.browser_fallback: Optional[BrowserFallback] = (
            BrowserFallback(browser_concurrency) if self.use_browser_fallback else None
        )
        self.cookies_file = cookies_file

        # Scope control derived from first start URL per scope
        self.scopes: List[Tuple[str, str]] = []  # (base_netloc, base_path)
        for su in self.start_urls:
            p = urlparse(su)
            base_path = p.path if p.path else "/"
            self.scopes.append((p.netloc, base_path.rstrip("/")))

        # Visited set for this run
        self.visited: Set[str] = set()
        self.enqueued: Set[str] = set()

        # HTTP client
        limits = httpx.Limits(max_connections=self.concurrency * 2, max_keepalive_connections=self.concurrency)
        cookies_jar = load_netscape_cookies(self.cookies_file) if self.cookies_file else None
        self.client = httpx.AsyncClient(
            headers={
                # Modern Chrome UA on macOS
                "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36",
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
                "Accept-Language": "en-US,en;q=0.9",
                "Accept-Encoding": "gzip, deflate",
                "Cache-Control": "no-cache",
                "Pragma": "no-cache",
                "Upgrade-Insecure-Requests": "1",
            },
            timeout=httpx.Timeout(20.0, connect=10.0),
            limits=limits,
            follow_redirects=True,
            http2=True,
            verify=True,
            cookies=cookies_jar,
        )

        # Prepare per-start-url directories
        self.scope_dirs: Dict[str, Tuple[str, str]] = {}
        for su in self.start_urls:
            key = safe_dirname_from_start_url(su)
            raw_dir = os.path.join(self.scraped_dir, key)
            sum_dir = os.path.join(self.summaries_dir, key)
            os.makedirs(raw_dir, exist_ok=True)
            os.makedirs(sum_dir, exist_ok=True)
            self.scope_dirs[su] = (raw_dir, sum_dir)

        # Per-host concurrency guards
        self.host_semaphores: Dict[str, asyncio.Semaphore] = {}

    def in_any_scope(self, url: str) -> bool:
        for base_netloc, base_path in self.scopes:
            if within_scope(url, base_netloc, base_path):
                return True
        return False

    async def close(self):
        await self.client.aclose()
        if self.browser_fallback:
            await self.browser_fallback.close()

    async def fetch(self, url: str) -> Optional[str]:
        try:
            # Per-host concurrency + small jitter
            host = urlparse(url).netloc
            sem = self.host_semaphores.get(host)
            if sem is None:
                sem = self.host_semaphores.setdefault(host, asyncio.Semaphore(self.per_host_limit))
            async with sem:
                if JITTER_MAX_S > 0:
                    await asyncio.sleep(random.uniform(max(0.0, JITTER_MIN_S), max(JITTER_MIN_S, JITTER_MAX_S)))

                # Per-request Referer
                try:
                    p = urlparse(url)
                    referer = f"{p.scheme}://{p.netloc}/"
                except Exception:
                    referer = None

                headers = {"Referer": referer} if referer else None
                r = await self.client.get(url, headers=headers)
            ct = r.headers.get("content-type", "")
            if r.status_code != 200:
                # Optional browser fallback for 403/429
                if self.browser_fallback and r.status_code in (403, 429):
                    html = await self.browser_fallback.fetch(url, referer)
                    if html:
                        return html
                return None
            if "text/html" not in ct and not looks_like_html(url):
                return None
            return r.text
        except Exception as e:
            logger.debug(f"Fetch failed: {url} ({e})")
            return None

    async def worker(self, queue: asyncio.Queue, results: asyncio.Queue):
        while True:
            try:
                url = await queue.get()
                if url in self.visited:
                    queue.task_done()
                    continue
                self.visited.add(url)
                html = await self.fetch(url)
                if html:
                    title, text = extract_text(html)
                    await results.put(PageItem(url=url, title=title, text=text))
                    # Discover new links
                    try:
                        soup = BeautifulSoup(html, "lxml")
                        for a in soup.find_all("a", href=True):
                            nu = normalize_url(url, a.get("href"))
                            if not nu:
                                continue
                            # Strip query to reduce duplicate pages across tracking params
                            parsed = urlparse(nu)
                            nu_clean = parsed._replace(query="").geturl()
                            if not self.in_any_scope(nu_clean):
                                continue
                            if nu_clean not in self.visited and nu_clean not in self.enqueued and looks_like_html(nu_clean):
                                self.enqueued.add(nu_clean)
                                queue.put_nowait(nu_clean)
                    except Exception:
                        pass
                queue.task_done()
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.debug(f"Worker error: {e}")
                try:
                    queue.task_done()
                except Exception:
                    pass

    async def crawl(self) -> asyncio.Queue:
        queue: asyncio.Queue = asyncio.Queue()
        results: asyncio.Queue = asyncio.Queue()

        # Seed
        for su in self.start_urls:
            nu = normalize_url(su, "") or su
            if nu not in self.enqueued:
                self.enqueued.add(nu)
                queue.put_nowait(nu)

        # Spawn workers
        workers = [asyncio.create_task(self.worker(queue, results)) for _ in range(self.concurrency)]

        # Supervise until max_pages reached and queue drained
        pages_processed = 0
        try:
            while True:
                if self.max_pages and pages_processed >= self.max_pages:
                    break
                try:
                    item = await asyncio.wait_for(results.get(), timeout=2.0)
                except asyncio.TimeoutError:
                    # If queue empty and no more results incoming, break
                    if queue.empty():
                        break
                    else:
                        continue
                yield item
                pages_processed += 1
        finally:
            # Cancel workers
            for w in workers:
                w.cancel()
            await asyncio.gather(*workers, return_exceptions=True)
            await self.close()


# ----------------------
# Orchestrate ETL to Milvus
# ----------------------
async def process_pipeline(
    start_urls: List[str],
    concurrency: int,
    max_pages: Optional[int],
    collection_name: str,
    scraped_dir: str,
    summaries_dir: str,
    milvus_db_path: str,
    per_host_limit: int = PER_HOST_LIMIT,
    use_browser_fallback: bool = False,
    browser_concurrency: int = 2,
    cookies_file: Optional[str] = DEFAULT_COOKIES_FILE,
):
    scraper = Scraper(
        start_urls,
        concurrency,
        max_pages,
        scraped_dir,
        summaries_dir,
        per_host_limit=per_host_limit,
        use_browser_fallback=use_browser_fallback,
        browser_concurrency=browser_concurrency,
        cookies_file=cookies_file,
    )
    summarizer = AzureSummarizer(concurrency=concurrency)
    embedder = AzureEmbedder(concurrency=concurrency)
    store = MilvusStore(milvus_db_path, collection_name)

    # Map start URL -> (raw_dir, sum_dir)
    scope_dirs = scraper.scope_dirs

    # Helper to choose correct scope dir by netloc and base_path match
    def choose_scope(url: str) -> Tuple[str, str]:
        up = urlparse(url)
        best: Optional[Tuple[str, str]] = None
        best_len = -1
        for su, (raw_dir, sum_dir) in scope_dirs.items():
            sp = urlparse(su)
            if up.netloc != sp.netloc:
                continue
            base_path = sp.path or "/"
            path = up.path or "/"
            # strict prefix semantics
            if not base_path.endswith("/"):
                matches = path == base_path or path.startswith(base_path + "/")
            else:
                matches = path.startswith(base_path)
            if matches:
                l = len(base_path)
                if l > best_len:
                    best = (raw_dir, sum_dir)
                    best_len = l
        # Fallback to first scope
        if best is None:
            first = next(iter(scope_dirs.values()))
            return first
        return best

    # Page processor with error isolation
    async def handle_page(page: PageItem):
        try:
            raw_dir, sum_dir = choose_scope(page.url)
            fid = sha256_hex(page.url)
            raw_path = os.path.join(raw_dir, f"{fid}.txt")
            summary_path = os.path.join(sum_dir, f"{fid}.txt")
            content_sha = sha256_hex(page.text)

            def _write(path: str, content: str):
                os.makedirs(os.path.dirname(path), exist_ok=True)
                with open(path, "w", encoding="utf-8") as f:
                    f.write(content)

            # Save raw immediately
            await asyncio.to_thread(_write, raw_path, page.text)

            # Summarize and save
            summary = await summarizer.summarize(page.text)
            summary_sha = sha256_hex(summary)
            await asyncio.to_thread(_write, summary_path, summary)

            # Embed
            embedding = await embedder.embed(summary)
            if not embedding:
                embedding = [0.0] * EMBEDDING_DIM
            elif len(embedding) != EMBEDDING_DIM:
                if len(embedding) > EMBEDDING_DIM:
                    embedding = embedding[:EMBEDDING_DIM]
                else:
                    embedding = embedding + [0.0] * (EMBEDDING_DIM - len(embedding))

            row = {
                "url": page.url,
                "title": page.title,
                "raw_path": os.path.relpath(raw_path),
                "summary_path": os.path.relpath(summary_path),
                "content_sha": content_sha,
                "summary_sha": summary_sha,
                "summary": summary,
                "embedding": embedding,
            }
            _id = store.insert(row)
            logger.info(f"Stored id={_id} url={page.url} title={page.title[:80]!r}")
        except Exception as e:
            logger.error(f"Failed processing page {page.url}: {e}")

    # Process pages concurrently
    tasks: Set[asyncio.Task] = set()
    processed = 0
    async for page in scraper.crawl():
        t = asyncio.create_task(handle_page(page))
        tasks.add(t)
        processed += 1
        # Cap number of concurrent processing tasks
        if len(tasks) >= concurrency:
            done, pending = await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
            tasks = pending
        # Respect max_pages if scraper isn't enforcing strictly due to pipeline parallelism
        if max_pages and processed >= max_pages:
            break
    if tasks:
        await asyncio.gather(*tasks, return_exceptions=True)


# ----------------------
# CLI
# ----------------------

def parse_args(argv: List[str]) -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Unified scraper+summary+embedding pipeline (Milvus Lite)")
    p.add_argument("--start-urls", nargs="+", required=True, help="One or more start URLs (scope restricted to each subpath)")
    p.add_argument("--concurrency", type=int, default=DEFAULT_CONCURRENCY, help="Scraper & Azure concurrency")
    p.add_argument("--max-pages", type=int, default=None, help="Optional max pages to process")
    p.add_argument("--collection-name", type=str, default=DEFAULT_COLLECTION_NAME, help="Milvus collection name")
    p.add_argument("--scraped-dir", type=str, default=DEFAULT_SCRAPED_DIR, help="Directory for raw pages")
    p.add_argument("--summaries-dir", type=str, default=DEFAULT_SUMMARIES_DIR, help="Directory for summaries")
    p.add_argument("--milvus-db-path", type=str, default=DEFAULT_MILVUS_DB_PATH, help="Path to Milvus Lite DB file")
    # Anti-403 tuning and fallback
    p.add_argument("--per-host-limit", type=int, default=PER_HOST_LIMIT, help="Max concurrent requests per host")
    p.add_argument("--jitter-min-ms", type=int, default=int(JITTER_MIN_S * 1000), help="Min jitter before requests (ms)")
    p.add_argument("--jitter-max-ms", type=int, default=int(JITTER_MAX_S * 1000), help="Max jitter before requests (ms)")
    p.add_argument("--cookies-file", type=str, default=DEFAULT_COOKIES_FILE, help="Path to cookies.txt (Netscape format)")
    p.add_argument("--use-browser-fallback", action="store_true", help="Use Playwright fallback for 403/429 pages")
    p.add_argument("--browser-concurrency", type=int, default=2, help="Playwright page concurrency when fallback is enabled")
    return p.parse_args(argv)


async def amain(argv: List[str]):
    args = parse_args(argv)
    t0 = time.time()
    try:
        # Allow per-run jitter override
        global JITTER_MIN_S, JITTER_MAX_S
        JITTER_MIN_S = max(0.0, float(args.jitter_min_ms) / 1000.0)
        JITTER_MAX_S = max(JITTER_MIN_S, float(args.jitter_max_ms) / 1000.0)
        await process_pipeline(
            start_urls=args.start_urls,
            concurrency=args.concurrency,
            max_pages=args.max_pages,
            collection_name=args.collection_name,
            scraped_dir=args.scraped_dir,
            summaries_dir=args.summaries_dir,
            milvus_db_path=args.milvus_db_path,
            per_host_limit=args.per_host_limit,
            use_browser_fallback=args.use_browser_fallback,
            browser_concurrency=args.browser_concurrency,
            cookies_file=args.cookies_file,
        )
    finally:
        logger.info(f"Done in {time.time()-t0:.2f}s")


def main():
    try:
        asyncio.run(amain(sys.argv[1:]))
    except KeyboardInterrupt:
        logger.info("Interrupted")


if __name__ == "__main__":
    main()
